# Rosa Aurora · Plataforma web y panel administrativo de maquillaje

Taller 4 de Construcción de Software II — Spring Boot (MVC) + Thymeleaf + HTML/CSS/JS + **MySQL con JPA / Hibernate**.

## Cómo ejecutarlo
1. Requisitos: JDK 17 o superior y **MySQL encendido** (puerto 3306).
2. En `src/main/resources/application.properties` pon tu usuario y contraseña de MySQL
   (por defecto `root` / `root`; en XAMPP: `root` y vacío).
3. Si ya habías ejecutado una versión anterior, borra su base para que se cree limpia
   (en MySQL Workbench): `DROP DATABASE maquillajedb;`
4. Ejecuta `MaquillajeApplication.java` con **Run**, o en la terminal: `./mvnw spring-boot:run`
   (Windows: `mvnw.cmd spring-boot:run`).
5. Abre <http://localhost:8081>. La base `maquillajedb`, sus tablas y los datos iniciales se crean solos.

## Usuarios
| Rol | Usuario | Contraseña | Cómo se obtiene |
|---|---|---|---|
| Administrador | `admin` | `admin123` | Se crea solo al arrancar (`config/DatosIniciales.java`) |
| Cliente | el que tú elijas | el que tú elijas | Pantalla **Registrarse** |

Las contraseñas se guardan cifradas con BCrypt. Se puede iniciar sesión con el usuario o con el correo.

## Dónde está cada requisito del enunciado
| Requisito | Dónde |
|---|---|
| Registro e inicio de sesión (pantallas) | `controller/AuthController.java`, `templates/registro.html`, `templates/login.html` |
| Dos roles: ADMIN y CLIENTE | `model/Rol.java`, `model/Usuario.java` |
| Sin sesión no se compra / sin ser admin no se entra al panel | `seguridad/AutenticacionInterceptor.java`, `config/WebConfig.java` |
| CRUD de productos (nombre, precio, contenido, categoría, color, imagen, stock, marca) | `controller/AdminController.java`, `templates/admin.html` |
| CRUD de marcas (nombre, país, descripción, logo) | `controller/AdminMarcaController.java`, `templates/admin-marcas.html` |
| Administrar pedidos y cambiar su estado | `controller/AdminPedidoController.java`, `templates/admin-pedidos.html` |
| 10 productos con precios reales y 4 marcas | `config/DatosIniciales.java` |
| Catálogo en tarjetas con filtros por categoría y marca | `templates/index.html`, `static/js/app.js` |
| Elegir tono, agregar, editar cantidad y eliminar del carrito (un carrito por usuario) | `service/CarritoService.java`, `templates/carrito.html` |
| Envío estándar $10.000 (3-5 días) y express $18.000 (24 h) | `model/MetodoEnvio.java` |
| Validación de inventario al agregar, al cambiar cantidad y al confirmar | `CarritoService.agregar/actualizarCantidad`, `PedidoService.generarPedido` |
| Descuento automático del stock al confirmar el pedido | `PedidoService.generarPedido` |
| Total = subtotales + envío | `CarritoService.calcularTotal()` |
| Confirmación de pedido (productos, marca, tono, envío, total, estado) | `templates/pedido.html` |
| Historial de compras del cliente | `templates/pedidos.html` |
| Logo, nombre, footer con año, ciudad y redes | `templates/fragmentos.html` |

## Tablas de MySQL
`productos`, `marcas`, `usuarios`, `pedidos`, `detalle_pedido` y `carrito` (el carrito de cada usuario).
Las columnas mínimas del enunciado están todas (`contenido_neto`, `color`, `stock`, `marca_id`, `metodo_envio`, `envio`, `estado`, `pedido_id`...).
Nota: la columna de la contraseña se llama `contrasena` (sin ñ) para evitar problemas de codificación en MySQL.

## Notas
- La columna `color` de `productos` guarda los tonos como `Rosa=#f4a6b8, Coral=#ff7f6e` (se editan así en el panel).
- El stock es por producto: si hay varios tonos del mismo producto en el carrito, se suman para validar el inventario.
- El pedido guarda una **copia** de los datos de cada producto: si luego cambias o eliminas un producto, los pedidos viejos no se alteran.
- Una marca con productos asociados no se puede eliminar.
- Las imágenes de los productos son **locales** (`static/img/productos/`), así que la app no depende de Internet para mostrarlas. Para usar una foto propia, copia el archivo a `static/img/productos/` y escribe su ruta (por ejemplo `/img/productos/labial.jpg`) en el campo *Foto* del panel. Si una imagen falla, se muestra la ilustración del producto. Una marca sin logo usa `/img/logo.svg`.
- Lo único que sí usa Internet es la tipografía (Google Fonts); sin conexión se ve con letra del sistema.
- La prueba `MaquillajeApplicationTests` necesita MySQL encendido.
