package com.maquillaje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaquillajeApplicationTests {

    @Test
    void contextLoads() {
    }
}
