/* Rosa Aurora - interactividad del catálogo (sin librerías) */
document.addEventListener('DOMContentLoaded', () => {

    /* ---------- Aviso emergente ---------- */
    function avisar(mensaje, esError) {
        let toast = document.getElementById('toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'toast';
            document.body.appendChild(toast);
        }
        toast.textContent = mensaje;
        toast.classList.toggle('toast-error', Boolean(esError));   // rojo si es una advertencia
        toast.classList.add('visible');
        clearTimeout(toast.temporizador);
        toast.temporizador = setTimeout(() => toast.classList.remove('visible'), 2800);
    }

    /* Los mensajes verdes del servidor se desvanecen solos */
    document.querySelectorAll('.alerta[data-auto]').forEach(a => {
        setTimeout(() => { a.style.opacity = '0'; }, 3500);
        setTimeout(() => { a.remove(); }, 4200);
    });

    /* ---------- Filtros del catálogo ---------- */
    // Guarda todas las tarjetas para poder filtrarlas sin volver a consultar el DOM.
    const tarjetas = [...document.querySelectorAll('.tarjeta')];
    // Conserva los filtros elegidos por el usuario.
    const estado = { categoria: 'Todas', marca: '', texto: '' };

    // Oculta las tarjetas que no coinciden con categoría, marca y búsqueda.
    function filtrar() {
        let visibles = 0;
        tarjetas.forEach(t => {
            const coincide =
                (estado.categoria === 'Todas' || t.dataset.categoria === estado.categoria) &&
                (estado.marca === '' || t.dataset.marca === estado.marca) &&
                t.dataset.buscar.includes(estado.texto);
            t.hidden = !coincide;
            if (coincide) visibles++;
        });
        const cuenta = document.getElementById('cuenta');
        const vacio = document.getElementById('sin-resultados');
        if (cuenta) cuenta.textContent = 'Mostrando ' + visibles + ' de ' + tarjetas.length + ' productos';
        if (vacio) vacio.hidden = visibles !== 0;
    }

    document.querySelectorAll('[data-filtro-categoria]').forEach(boton => {
        boton.addEventListener('click', () => {
            estado.categoria = boton.dataset.filtroCategoria;
            document.querySelectorAll('.chip-categoria').forEach(c =>
                c.classList.toggle('activo', c === boton));
            filtrar();
        });
    });

    document.querySelectorAll('[data-filtro-marca]').forEach(boton => {
        boton.addEventListener('click', () => {
            const elegida = boton.dataset.filtroMarca;
            const esChip = boton.classList.contains('chip-marca');
            estado.marca = (esChip && estado.marca === elegida) ? '' : elegida;
            document.querySelectorAll('.chip-marca').forEach(c =>
                c.classList.toggle('activo', c.dataset.filtroMarca === estado.marca));
            filtrar();
            if (!esChip) {   // botón "Ver productos" de la sección de marcas
                document.getElementById('catalogo').scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Actualiza el filtro de texto cada vez que el usuario escribe.
    const buscador = document.getElementById('buscador');
    if (buscador) {
        buscador.addEventListener('input', () => {
            estado.texto = buscador.value.trim().toLowerCase();
            filtrar();
        });
    }
    if (tarjetas.length) filtrar();

    /* ---------- Elegir tono: la tarjeta y el producto se pintan de ese color ---------- */
    document.querySelectorAll('.muestra input').forEach(radio => {
        radio.addEventListener('change', () => {
            const tarjeta = radio.closest('.tarjeta');
            tarjeta.style.setProperty('--tono', radio.dataset.hex);
            tarjeta.querySelector('.tono-nombre').textContent = radio.value;
        });
    });

    /* ---------- Botones + / - de la cantidad ---------- */
    document.querySelectorAll('.stepper').forEach(stepper => {
        const campo = stepper.querySelector('input');
        stepper.querySelectorAll('button').forEach(boton => {
            boton.addEventListener('click', () => {
                const nuevo = (parseInt(campo.value, 10) || 1) + parseInt(boton.dataset.paso, 10);
                campo.value = Math.min(20, Math.max(1, nuevo));
            });
        });
    });

    /* ---------- Agregar al carrito sin recargar la página ---------- */
    document.querySelectorAll('.form-agregar').forEach(formulario => {
        formulario.addEventListener('submit', async evento => {
            evento.preventDefault();
            const tarjeta = formulario.closest('.tarjeta');
            const boton = formulario.querySelector('.boton-agregar');
            try {
                // Envía el formulario al servidor en segundo plano para no recargar la página.
                const respuesta = await fetch(formulario.action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'fetch',
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams(new FormData(formulario))
                });
                // 401: no ha iniciado sesión -> se le lleva a la pantalla de inicio de sesión
                if (respuesta.status === 401) {
                    window.location.href = '/login?requerido';
                    return;
                }
                // 409: no hay stock suficiente -> advertencia y no se agrega nada
                if (respuesta.status === 409) {
                    avisar(await respuesta.text(), true);
                    return;
                }
                if (!respuesta.ok) throw new Error('Error al agregar');

                const unidades = await respuesta.text();
                const contador = document.querySelector('.contador');
                contador.textContent = unidades;
                contador.classList.remove('rebote');
                void contador.offsetWidth;            // reinicia la animación
                contador.classList.add('rebote');

                boton.textContent = '¡Agregado! ✓';
                boton.classList.add('agregado');
                setTimeout(() => {
                    boton.textContent = 'Agregar al carrito';
                    boton.classList.remove('agregado');
                }, 1400);
                avisar(tarjeta.dataset.nombre + ' se agregó a tu carrito 💖');
            } catch (error) {
                formulario.submit();   // respaldo: envío normal del formulario
            }
        });
    });
});
