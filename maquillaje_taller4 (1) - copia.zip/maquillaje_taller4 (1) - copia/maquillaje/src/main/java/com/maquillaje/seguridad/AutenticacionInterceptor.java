
package com.maquillaje.seguridad;

// Interfaz de Spring que permite interceptar las peticiones antes de llegar al controlador.
import org.springframework.web.servlet.HandlerInterceptor;

import com.maquillaje.model.Rol;

// Clases necesarias para trabajar con las peticiones y respuestas HTTP.
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Interceptor encargado de proteger las rutas de la aplicación.
 * Se ejecuta antes de que una petición llegue al controlador.
 *
 * Comprueba si el usuario inició sesión y si tiene el rol necesario
 * para acceder a la página solicitada.
 *
 * Si no cumple las condiciones, bloquea el acceso y lo redirige
 * o devuelve un código de error.
 */
public class AutenticacionInterceptor implements HandlerInterceptor {

    // Almacena el rol que debe tener el usuario para acceder a una ruta.
    private final Rol rolRequerido;

    // Constructor que recibe y establece el rol necesario para acceder.
    public AutenticacionInterceptor(Rol rolRequerido) {
        this.rolRequerido = rolRequerido;
    }

    // Método que se ejecuta antes de ingresar al controlador.
    // Decide si la petición puede continuar o debe ser bloqueada.
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        // Obtiene la sesión existente sin crear una nueva.
        HttpSession sesion = request.getSession(false);

        // Comprueba si la petición proviene de JavaScript mediante fetch.
        // Estas peticiones reciben códigos HTTP en lugar de una redirección.
        boolean esFetch = "fetch".equals(request.getHeader("X-Requested-With"));

        // Obtiene la ruta base de la aplicación.
        String raiz = request.getContextPath();

        // Comprueba si existe una sesión autenticada.
        if (!SesionUsuario.estaAutenticado(sesion)) {

            // Si es una petición fetch, responde con error 401 (no autorizado).
            if (esFetch) {
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED);

            // Si es una petición normal, redirige al formulario de inicio de sesión.
            } else {
                response.sendRedirect(raiz + "/login?requerido");
            }

            // Detiene la petición para evitar que llegue al controlador.
            return false;
        }

        // Obtiene el rol del usuario que inició sesión.
        Rol rol = SesionUsuario.rol(sesion);

        // Compara el rol del usuario con el rol requerido por la ruta.
        if (rol != rolRequerido) {

            // Si es una petición fetch, responde con error 403 (acceso prohibido).
            if (esFetch) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);

            // Si el usuario es administrador, lo envía al panel administrativo.
            } else if (rol == Rol.ADMIN) {
                response.sendRedirect(raiz + "/admin");        // el admin no compra

            // Si es cliente, lo envía al catálogo principal.
            } else {
                response.sendRedirect(raiz + "/?denegado");     // el cliente no administra
            }

            // Bloquea el acceso porque el usuario no tiene el rol requerido.
            return false;
        }

        // Si está autenticado y tiene el rol correcto, permite continuar al controlador.
        return true;
    }
}
