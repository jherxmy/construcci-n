
package com.maquillaje.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/*
 * Representa la entidad Pedido en la base de datos.
 * Almacena la información de las compras realizadas por los clientes,
 * incluyendo fecha, dirección, método de envío, valores y estado.
 */
@Entity
@Table(name = "pedidos")
public class Pedido {

    // Identificador único del pedido.
    // MySQL genera automáticamente este número.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Cliente que realizó el pedido.
    // La columna usuario_id establece la relación con la tabla Usuario.
    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    // Dirección donde se debe entregar el pedido.
    private String direccion;

    // Fecha y hora en la que se realizó el pedido.
    private LocalDateTime fecha;

    /*
     * Almacena el método de envío seleccionado.
     * EnumType.STRING permite guardar el nombre del valor del enum
     * como texto en la base de datos.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "metodo_envio")
    private MetodoEnvio metodoEnvio;

    // Suma del valor de todos los productos comprados.
    private int subtotal;

    // Costo correspondiente al método de envío seleccionado.
    @Column(name = "envio")
    private int costoEnvio;

    // Valor total de la compra, incluyendo el costo del envío.
    private int total;

    // Estado actual del pedido, por ejemplo: CONFIRMADO o ENVIADO.
    @Enumerated(EnumType.STRING)
    private EstadoPedido estado;

    /*
     * Relación uno a muchos: un pedido puede tener varios detalles,
     * es decir, varios productos incluidos en la misma compra.
     *
     * CascadeType.ALL permite aplicar las operaciones de persistencia
     * del pedido también a sus detalles.
     *
     * FetchType.EAGER hace que los detalles se consulten junto con el pedido.
     */
    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<DetallePedido> detalles = new ArrayList<>();

    // Constructor vacío requerido por JPA para crear objetos de esta entidad.
    public Pedido() {
    }

    /*
     * Constructor que permite crear un pedido con sus datos principales.
     * Recibe el cliente, dirección, fecha, envío, valores y estado inicial.
     */
    public Pedido(Usuario usuario, String direccion, LocalDateTime fecha, MetodoEnvio metodoEnvio,
                  int subtotal, int costoEnvio, int total, EstadoPedido estado) {
        this.usuario = usuario;
        this.direccion = direccion;
        this.fecha = fecha;
        this.metodoEnvio = metodoEnvio;
        this.subtotal = subtotal;
        this.costoEnvio = costoEnvio;
        this.total = total;
        this.estado = estado;
    }

    /*
     * Agrega un detalle a la lista de productos del pedido.
     * También establece la relación entre el detalle y este pedido.
     */
    public void agregarDetalle(DetallePedido detalle) {
        detalle.setPedido(this);
        detalles.add(detalle);
    }

    // Métodos getter: permiten consultar la información del pedido.
    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public String getDireccion() { return direccion; }
    public LocalDateTime getFecha() { return fecha; }
    public MetodoEnvio getMetodoEnvio() { return metodoEnvio; }
    public int getSubtotal() { return subtotal; }
    public int getCostoEnvio() { return costoEnvio; }
    public int getTotal() { return total; }
    public EstadoPedido getEstado() { return estado; }

    // Permite actualizar el estado del pedido, por ejemplo, de CONFIRMADO a ENVIADO.
    public void setEstado(EstadoPedido estado) { this.estado = estado; }

    // Devuelve la lista de productos que pertenecen al pedido.
    public List<DetallePedido> getDetalles() { return detalles; }
}
