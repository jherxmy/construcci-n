
package com.maquillaje.service;

// Permite crear listas dinámicas.
import java.util.ArrayList;
import java.util.List;

// Permite ordenar los resultados obtenidos de la base de datos.
import org.springframework.data.domain.Sort;

// Identifica esta clase como un servicio administrado por Spring.
import org.springframework.stereotype.Service;

// Permite ejecutar operaciones dentro de una transacción.
import org.springframework.transaction.annotation.Transactional;

import com.maquillaje.model.Marca;
import com.maquillaje.model.Producto;
import com.maquillaje.repository.MarcaRepository;
import com.maquillaje.repository.ProductoRepository;

/**
 * Servicio encargado de administrar el catálogo de la tienda.
 * Permite consultar, registrar, actualizar y eliminar productos y marcas.
 * La información se obtiene y se guarda en la base de datos MySQL.
 */
@Service
public class CatalogoService {

    // Repositorio encargado de realizar las operaciones con los productos.
    private final ProductoRepository productoRepositorio;

    // Repositorio encargado de realizar las operaciones con las marcas.
    private final MarcaRepository marcaRepositorio;

    // ---------- Constructor e inyección de dependencias ----------

    // Spring entrega automáticamente los repositorios necesarios para trabajar.
    public CatalogoService(ProductoRepository productoRepositorio, MarcaRepository marcaRepositorio) {
        this.productoRepositorio = productoRepositorio;
        this.marcaRepositorio = marcaRepositorio;
    }

    // ---------- Productos ----------

    // Consulta todos los productos registrados en la base de datos.
    // SELECT * FROM productos
    public List<Producto> listarProductos() {

        // Obtiene los productos ordenados por su identificador de menor a mayor.
        return productoRepositorio.findAllByOrderByIdAsc();
    }

    // Busca un producto utilizando su identificador.
    // SELECT * FROM productos WHERE id = ?
    // Si no existe, retorna null.
    public Producto buscarProducto(Long id) {

        // Busca el producto por su ID y obtiene el resultado si existe.
        return productoRepositorio.findById(id).orElse(null);
    }

    /**
     * Registra un producto nuevo o actualiza uno que ya existe.
     * INSERT: cuando se guarda un producto nuevo.
     * UPDATE: cuando se guarda un producto existente.
     */
    @Transactional
    public Producto guardar(Producto producto) {

        // Utiliza el repositorio para guardar el producto en la base de datos.
        return productoRepositorio.save(producto);
    }

    // Elimina un producto utilizando su identificador.
    // DELETE FROM productos WHERE id = ?
    @Transactional
    public void eliminar(Long id) {

        // Comprueba primero si el producto existe.
        if (productoRepositorio.existsById(id)) {

            // Si existe, lo elimina de la base de datos.
            productoRepositorio.deleteById(id);
        }
    }

    /**
     * Obtiene las categorías de los productos sin repetirlas.
     * Mantiene el orden en el que aparecen al recorrer los productos.
     */
    public List<String> listarCategorias() {

        // Crea una lista vacía para almacenar las categorías.
        List<String> categorias = new ArrayList<>();

        // Recorre todos los productos registrados.
        for (Producto producto : listarProductos()) {

            // Comprueba si la categoría del producto todavía no está en la lista.
            if (!categorias.contains(producto.getCategoria())) {

                // Si no existe, agrega la categoría.
                categorias.add(producto.getCategoria());
            }
        }

        // Retorna la lista de categorías sin duplicados.
        return categorias;
    }

    // ---------- Marcas ----------

    // Consulta todas las marcas registradas en la base de datos.
    public List<Marca> listarMarcas() {

        // Obtiene las marcas ordenadas por su identificador.
        return marcaRepositorio.findAll(Sort.by("id"));
    }

    // Busca una marca utilizando su identificador.
    // Si no existe, retorna null.
    public Marca buscarMarca(Long id) {

        // Busca la marca y obtiene el resultado si existe.
        return marcaRepositorio.findById(id).orElse(null);
    }

    /**
     * Registra una marca nueva o actualiza una que ya existe.
     * INSERT: cuando se guarda una marca nueva.
     * UPDATE: cuando se guarda una marca existente.
     */
    @Transactional
    public Marca guardarMarca(Marca marca) {

        // Utiliza el repositorio para guardar la marca en la base de datos.
        return marcaRepositorio.save(marca);
    }

    /**
     * Cuenta cuántos productos están asociados a una marca.
     * Este método permite comprobar si una marca tiene productos relacionados.
     */
    public long contarProductosDeMarca(Long marcaId) {

        // Consulta el repositorio y retorna la cantidad de productos asociados a la marca.
        return productoRepositorio.countByMarcaId(marcaId);
    }

    // Elimina una marca utilizando su identificador.
    // DELETE FROM marcas WHERE id = ?
    @Transactional
    public void eliminarMarca(Long id) {

        // Comprueba si la marca existe en la base de datos.
        if (marcaRepositorio.existsById(id)) {

            // Si existe, elimina la marca.
            marcaRepositorio.deleteById(id);
        }
    }
}
