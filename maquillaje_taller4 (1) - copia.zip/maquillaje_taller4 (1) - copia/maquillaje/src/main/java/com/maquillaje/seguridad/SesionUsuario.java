
package com.maquillaje.seguridad;

// Importa las clases del modelo que se utilizan para manejar los datos del usuario.
import com.maquillaje.model.MetodoEnvio;
import com.maquillaje.model.Rol;
import com.maquillaje.model.Usuario;

// Permite trabajar con la sesión del usuario en el servidor.
import jakarta.servlet.http.HttpSession;

/**
 * Clase encargada de administrar los datos del usuario que inició sesión.
 *
 * Utiliza HttpSession para guardar información como el identificador,
 * nombre, rol y método de envío seleccionado.
 *
 * La información permanece disponible mientras la sesión esté activa.
 */
public final class SesionUsuario {

    // Nombres de los atributos que se almacenan dentro de la sesión.
    public static final String ID = "usuarioId";
    public static final String NOMBRE = "usuarioNombre";
    public static final String ROL = "usuarioRol";
    public static final String ENVIO = "metodoEnvio";

    // Constructor privado para impedir que se creen objetos de esta clase.
    // Sus métodos son estáticos, por lo que se pueden utilizar directamente.
    private SesionUsuario() {
    }

    /**
     * Guarda en la sesión los datos del usuario que acaba de iniciar sesión.
     */
    public static void iniciar(HttpSession sesion, Usuario usuario) {

        // Guarda el identificador del usuario.
        sesion.setAttribute(ID, usuario.getId());

        // Guarda el nombre completo del usuario.
        sesion.setAttribute(NOMBRE, usuario.getNombreCompleto());

        // Guarda el rol del usuario como texto.
        sesion.setAttribute(ROL, usuario.getRol().name());
    }

    // Obtiene el identificador del usuario almacenado en la sesión.
    public static Long id(HttpSession sesion) {

        // Si no existe una sesión, retorna null.
        if (sesion == null) {
            return null;
        }

        // Obtiene el valor asociado al identificador del usuario.
        Object valor = sesion.getAttribute(ID);

        // Comprueba que el valor sea de tipo Long.
        // Si lo es, lo retorna; de lo contrario, retorna null.
        return valor instanceof Long ? (Long) valor : null;
    }

    // Comprueba si existe un identificador de usuario en la sesión.
    // Si existe, considera que el usuario está autenticado.
    public static boolean estaAutenticado(HttpSession sesion) {
        return id(sesion) != null;
    }

    // Obtiene el nombre del usuario almacenado en la sesión.
    public static String nombre(HttpSession sesion) {

        // Si no existe una sesión, retorna null.
        if (sesion == null) {
            return null;
        }

        // Obtiene el nombre guardado en la sesión.
        Object valor = sesion.getAttribute(NOMBRE);

        // Si el valor existe, lo convierte a String; si no, retorna null.
        return valor == null ? null : valor.toString();
    }

    // Obtiene el rol del usuario y lo convierte nuevamente al enum Rol.
    public static Rol rol(HttpSession sesion) {

        // Si no existe una sesión, retorna null.
        if (sesion == null) {
            return null;
        }

        // Obtiene el rol almacenado en la sesión.
        Object valor = sesion.getAttribute(ROL);

        // Si existe un valor, lo convierte al tipo Rol; de lo contrario, retorna null.
        return valor == null ? null : Rol.valueOf(valor.toString());
    }

    // Comprueba si el usuario que inició sesión tiene el rol de administrador.
    public static boolean esAdmin(HttpSession sesion) {
        return rol(sesion) == Rol.ADMIN;
    }

    /**
     * Obtiene el método de envío seleccionado por el usuario.
     * Si todavía no ha seleccionado uno, utiliza el envío estándar.
     */
    public static MetodoEnvio envio(HttpSession sesion) {

        // Obtiene el método de envío almacenado en la sesión.
        Object valor = sesion.getAttribute(ENVIO);

        // Si no hay un método guardado, retorna el envío estándar.
        // Si existe, convierte el texto al enum MetodoEnvio.
        return valor == null ? MetodoEnvio.ESTANDAR : MetodoEnvio.valueOf(valor.toString());
    }

    // Guarda en la sesión el método de envío seleccionado por el usuario.
    public static void guardarEnvio(HttpSession sesion, MetodoEnvio envio) {

        // Almacena el nombre del método de envío como texto.
        sesion.setAttribute(ENVIO, envio.name());
    }
}
