
package com.maquillaje.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.maquillaje.model.Marca;
import com.maquillaje.service.CatalogoService;

/*
 * Controlador encargado de administrar las marcas del catálogo.
 * Permite registrar, consultar, editar y eliminar marcas.
 * Sus rutas están protegidas para usuarios con rol ADMIN.
 */
@Controller
@RequestMapping("/admin/marcas")
public class AdminMarcaController {

    // Ruta de la imagen que se utiliza cuando una marca no tiene logo.
    private static final String LOGO_POR_DEFECTO = "/img/logo.svg";

    // Servicio que permite consultar y gestionar las marcas.
    private final CatalogoService catalogoService;

    // Constructor que recibe el servicio mediante inyección de dependencias.
    public AdminMarcaController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    // Muestra el listado de marcas y un formulario vacío para registrar una nueva.
    @GetMapping
    public String listar(Model model) {
        return mostrar(model, new Marca(), false);
    }

    // Busca una marca por su ID y carga sus datos en el formulario de edición.
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable("id") Long id, Model model) {
        Marca marca = catalogoService.buscarMarca(id);

        // Si la marca no existe, regresa al listado principal.
        if (marca == null) {
            return "redirect:/admin/marcas";
        }

        return mostrar(model, marca, true);
    }

    /*
     * Prepara los datos que necesita la vista para mostrar las marcas.
     * También permite reutilizar el formulario para registrar y editar.
     */
    private String mostrar(Model model, Marca formulario, boolean editando) {
        model.addAttribute("marcas", catalogoService.listarMarcas());
        model.addAttribute("form", formulario);
        model.addAttribute("editando", editando);

        // Indica que se debe mostrar la página de administración de marcas.
        return "admin-marcas";
    }

    /*
     * Recibe los datos del formulario para registrar una marca nueva
     * o actualizar una marca que ya existe.
     */
    @PostMapping("/guardar")
    public String guardar(@RequestParam(name = "id", required = false) Long id,
                          @RequestParam("nombre") String nombre,
                          @RequestParam("pais") String pais,
                          @RequestParam("descripcion") String descripcion,
                          @RequestParam(name = "logo", defaultValue = "") String logo,
                          RedirectAttributes redirect) {

        // Define a dónde regresar según si se está registrando o editando.
        String volver = (id == null) ? "redirect:/admin/marcas" : "redirect:/admin/marcas/editar/" + id;

        // Comprueba que los campos obligatorios no estén vacíos.
        if (nombre.isBlank() || pais.isBlank() || descripcion.isBlank()) {
            redirect.addFlashAttribute("error", "Nombre, país de origen y descripción son obligatorios.");
            return volver;
        }

        // Crea una marca nueva o busca la marca que se desea modificar.
        Marca marca = (id == null) ? new Marca() : catalogoService.buscarMarca(id);

        // Si no encuentra la marca que se intenta editar, regresa al listado.
        if (marca == null) {
            return "redirect:/admin/marcas";
        }

        // Asigna a la marca los datos recibidos desde el formulario.
        marca.setNombre(nombre.trim());
        marca.setPais(pais.trim());
        marca.setDescripcion(descripcion.trim());

        // Si no se proporciona un logo, utiliza la imagen predeterminada.
        marca.setLogo(logo.isBlank() ? LOGO_POR_DEFECTO : logo.trim());

        // Guarda la marca en la base de datos: la inserta o actualiza según corresponda.
        catalogoService.guardarMarca(marca);

        // Muestra un mensaje diferente dependiendo de la operación realizada.
        redirect.addFlashAttribute("mensaje",
                (id == null ? "Marca registrada: " : "Marca actualizada: ") + marca.getNombre());

        return "redirect:/admin/marcas";
    }

    // Elimina una marca únicamente si no tiene productos asociados.
    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable("id") Long id, RedirectAttributes redirect) {

        // Consulta cuántos productos pertenecen a la marca seleccionada.
        long productos = catalogoService.contarProductosDeMarca(id);

        // Evita eliminar una marca que todavía está relacionada con productos.
        if (productos > 0) {
            redirect.addFlashAttribute("error", "No se puede eliminar: la marca tiene " + productos
                    + " producto(s) asociado(s). Cambia o elimina esos productos primero.");
            return "redirect:/admin/marcas";
        }

        // Si no tiene productos asociados, elimina la marca.
        catalogoService.eliminarMarca(id);

        // Informa que la marca fue eliminada correctamente.
        redirect.addFlashAttribute("mensaje", "Marca eliminada");

        return "redirect:/admin/marcas";
    }
}
