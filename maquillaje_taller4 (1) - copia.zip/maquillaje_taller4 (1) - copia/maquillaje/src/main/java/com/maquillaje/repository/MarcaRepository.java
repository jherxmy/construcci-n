package com.maquillaje.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maquillaje.model.Marca;

/** REPOSITORIO: se comunica con la tabla "marca" (save, findAll, findById, count...). */
public interface MarcaRepository extends JpaRepository<Marca, Long> {
}
