
package com.maquillaje.model;

// Importaciones de JPA para relacionar esta clase con una tabla de la base de datos.
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Representa un usuario registrado en el sistema.
 * Esta clase se relaciona con la tabla "usuarios" de la base de datos.
 *
 * Almacena el nombre completo, nombre de usuario,
 * correo electrónico, contraseña y rol.
 */
@Entity
@Table(name = "usuarios")
public class Usuario {

    // Identificador único del usuario.
    @Id

    // Indica que la base de datos genera automáticamente el identificador.
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nombre completo del usuario.
    // No puede ser nulo y permite almacenar hasta 120 caracteres.
    @Column(name = "nombre_completo", nullable = false, length = 120)
    private String nombreCompleto;

    // Nombre de usuario utilizado para iniciar sesión.
    // Es obligatorio, único y permite hasta 50 caracteres.
    @Column(nullable = false, unique = true, length = 50)
    private String usuario;

    // Correo electrónico del usuario.
    // Es obligatorio y no puede repetirse en la base de datos.
    @Column(nullable = false, unique = true, length = 120)
    private String correo;

    // Contraseña del usuario.
    // Se almacena cifrada mediante BCrypt, nunca en texto plano.
    @Column(nullable = false, length = 100)
    private String contrasena;

    // Rol que determina el tipo de usuario dentro del sistema.
    // EnumType.STRING permite guardar el nombre del rol como texto.
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Rol rol;

    // Constructor vacío obligatorio para que JPA pueda crear objetos.
    public Usuario() {
    }

    // Constructor que permite crear un usuario con todos sus datos.
    public Usuario(String nombreCompleto, String usuario, String correo, String contrasena, Rol rol) {
        this.nombreCompleto = nombreCompleto;
        this.usuario = usuario;
        this.correo = correo;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    // Retorna el identificador del usuario.
    public Long getId() { return id; }

    // Retorna el nombre completo del usuario.
    public String getNombreCompleto() { return nombreCompleto; }

    // Retorna el nombre de usuario.
    public String getUsuario() { return usuario; }

    // Retorna el correo electrónico.
    public String getCorreo() { return correo; }

    // Retorna la contraseña almacenada.
    public String getContrasena() { return contrasena; }

    // Retorna el rol asignado al usuario.
    public Rol getRol() { return rol; }
}
