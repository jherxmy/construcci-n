
package com.maquillaje.model;

/*
 * Enum que define los diferentes estados de un pedido.
 * Estos estados permiten identificar en qué etapa se encuentra
 * una compra y pueden ser actualizados por el administrador.
 */
public enum EstadoPedido {

    // El pedido fue confirmado correctamente.
    CONFIRMADO("Confirmado"),

    // El pedido se encuentra en proceso de preparación.
    EN_PREPARACION("En preparación"),

    // El pedido ya fue enviado al cliente.
    ENVIADO("Enviado"),

    // El pedido fue entregado al cliente.
    ENTREGADO("Entregado");

    // Almacena el nombre que se mostrará en la interfaz.
    private final String nombre;

    // Constructor que asigna el nombre visible a cada estado.
    EstadoPedido(String nombre) {
        this.nombre = nombre;
    }

    // Devuelve el nombre del estado para mostrarlo en la aplicación.
    public String getNombre() {
        return nombre;
    }
}
