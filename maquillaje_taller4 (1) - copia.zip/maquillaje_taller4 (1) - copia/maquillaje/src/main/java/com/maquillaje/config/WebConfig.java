
package com.maquillaje.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.maquillaje.model.Rol;
import com.maquillaje.seguridad.AutenticacionInterceptor;

/*
 * Configuración de seguridad de las rutas del sistema.
 * Define qué páginas necesitan autenticación y qué rol puede acceder.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /*
     * Registra los interceptores que revisan el acceso
     * de los usuarios a determinadas rutas.
     */
    @Override
    public void addInterceptors(InterceptorRegistry registro) {

        // Protege todas las rutas que comienzan con /admin.
        // Únicamente permite el acceso a usuarios con rol ADMIN.
        registro.addInterceptor(new AutenticacionInterceptor(Rol.ADMIN))
                .addPathPatterns("/admin/**");

        // Protege las rutas relacionadas con el carrito,
        // la compra y el historial de pedidos.
        // Para acceder, el usuario debe tener el rol CLIENTE.
        registro.addInterceptor(new AutenticacionInterceptor(Rol.CLIENTE))
                .addPathPatterns("/carrito/**", "/comprar", "/pedidos/**");
    }
}
