
package com.maquillaje.model;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * Representa cada elemento del carrito de compras en la base de datos.
 * Cada registro almacena el producto, el usuario, el tono seleccionado,
 * la cantidad y los valores correspondientes.
 */
@Entity
@Table(name = "carrito")
public class ItemCarrito {

    // Identificador único de cada línea del carrito.
    // MySQL genera automáticamente este valor.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lineaId;

    // Relaciona el elemento del carrito con el usuario propietario.
    // La columna usuario_id funciona como llave foránea.
    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    // Relaciona el elemento del carrito con un producto del catálogo.
    // La columna producto_id almacena esta relación.
    @ManyToOne
    @JoinColumn(name = "producto_id")
    private Producto producto;

    /*
     * Almacena el tono seleccionado por el cliente.
     * @Embedded permite guardar los atributos de Tono
     * directamente en las columnas de esta misma tabla.
     */
    @Embedded
    @AttributeOverrides({
            // Asigna el atributo nombre de Tono a la columna tono_nombre.
            @AttributeOverride(name = "nombre", column = @Column(name = "tono_nombre")),

            // Asigna el atributo hex de Tono a la columna tono_hex.
            @AttributeOverride(name = "hex", column = @Column(name = "tono_hex"))
    })
    private Tono tono;

    // Guarda una copia del nombre del producto.
    private String nombre;

    // Guarda el precio correspondiente a una unidad del producto.
    private int precio;

    // Almacena la cantidad de unidades agregadas al carrito.
    private int cantidad;

    // Guarda el resultado de multiplicar el precio por la cantidad.
    private int subtotal;

    // Constructor vacío necesario para que JPA pueda crear objetos de esta entidad.
    public ItemCarrito() {
    }

    /*
     * Constructor que inicializa un elemento del carrito.
     * Recibe el usuario, el producto, el tono seleccionado y la cantidad.
     */
    public ItemCarrito(Usuario usuario, Producto producto, Tono tono, int cantidad) {
        this.usuario = usuario;
        this.producto = producto;
        this.tono = tono;

        // Copia el nombre y el precio actual del producto.
        this.nombre = producto.getNombre();
        this.precio = producto.getPrecio();

        // Asigna la cantidad y calcula automáticamente el subtotal.
        setCantidad(cantidad);
    }

    /*
     * Actualiza la cantidad de unidades del producto.
     * También recalcula el subtotal para mantener actualizado su valor.
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        this.subtotal = precio * cantidad;
    }

    /*
     * Actualiza el nombre y el precio guardados en el carrito
     * cuando el administrador modifica los datos del producto.
     */
    public void actualizarDatosProducto() {
        this.nombre = producto.getNombre();
        this.precio = producto.getPrecio();

        // Recalcula el subtotal utilizando el nuevo precio.
        this.subtotal = precio * cantidad;
    }

    // Métodos getter: permiten consultar los atributos privados de la clase.
    public Long getLineaId() { return lineaId; }
    public Usuario getUsuario() { return usuario; }
    public Producto getProducto() { return producto; }
    public Tono getTono() { return tono; }
    public String getNombre() { return nombre; }
    public int getPrecio() { return precio; }
    public int getCantidad() { return cantidad; }
    public int getSubtotal() { return subtotal; }
}
