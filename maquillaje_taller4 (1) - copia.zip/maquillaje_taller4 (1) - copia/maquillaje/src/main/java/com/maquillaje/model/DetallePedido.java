
package com.maquillaje.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * Representa la entidad DetallePedido en la base de datos.
 * Almacena la información de cada producto incluido en una compra,
 * conservando sus datos tal como estaban en el momento de realizar el pedido.
 */
@Entity
@Table(name = "detalle_pedido")
public class DetallePedido {

    // Identificador único del detalle del pedido.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /*
     * Relación muchos a uno: varios detalles pueden pertenecer
     * a un mismo pedido. La columna pedido_id almacena la relación.
     */
    @ManyToOne
    @JoinColumn(name = "pedido_id")
    private Pedido pedido;

    // Guarda el nombre del producto al momento de realizar la compra.
    @Column(name = "producto")
    private String nombreProducto;

    // Guarda el nombre del tono seleccionado. Puede ser null si no tiene tonos.
    @Column(name = "color")
    private String tonoNombre;

    // Guarda el código hexadecimal del tono para representar su color.
    private String tonoHex;

    // Conserva la marca y categoría del producto al momento de la compra.
    private String marca;
    private String categoria;

    // Almacena el contenido neto del producto, por ejemplo: "30 ml".
    private String contenidoNeto;

    // Guarda el precio de una unidad del producto.
    private int precioUnitario;

    // Cantidad de unidades compradas.
    private int cantidad;

    // Resultado de multiplicar el precio unitario por la cantidad.
    private int subtotal;

    // Constructor vacío requerido por JPA para crear objetos de esta entidad.
    public DetallePedido() {
    }

    /*
     * Constructor que recibe un elemento del carrito y copia sus datos.
     * De esta manera, el pedido conserva la información original
     * aunque posteriormente se modifique o elimine el producto del catálogo.
     */
    public DetallePedido(ItemCarrito item) {

        // Obtiene el producto asociado a la línea del carrito.
        Producto producto = item.getProducto();

        // Copia los datos del producto y de su marca.
        this.nombreProducto = item.getNombre();
        this.marca = producto.getMarca().getNombre();
        this.categoria = producto.getCategoria();
        this.contenidoNeto = producto.getContenidoNeto();

        // Comprueba si el cliente seleccionó un tono.
        if (item.getTono() != null) {
            this.tonoNombre = item.getTono().getNombre();
            this.tonoHex = item.getTono().getHex();
        }

        // Copia los valores de la compra.
        this.precioUnitario = item.getPrecio();
        this.cantidad = item.getCantidad();
        this.subtotal = item.getSubtotal();
    }

    // Asigna el pedido al que pertenece este detalle.
    // Este método es utilizado por Pedido.agregarDetalle().
    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    // Métodos getter: permiten consultar los atributos privados de la clase.
    public Long getId() { return id; }
    public String getNombreProducto() { return nombreProducto; }
    public String getTonoNombre() { return tonoNombre; }
    public String getTonoHex() { return tonoHex; }
    public String getMarca() { return marca; }
    public String getCategoria() { return categoria; }
    public String getContenidoNeto() { return contenidoNeto; }
    public int getPrecioUnitario() { return precioUnitario; }
    public int getCantidad() { return cantidad; }
    public int getSubtotal() { return subtotal; }
}
