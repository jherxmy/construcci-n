package com.maquillaje.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maquillaje.model.Producto;

/** REPOSITORIO: se comunica con la tabla "productos". */
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    // MÉTODO POR NOMBRE: SELECT * FROM productos ORDER BY id ASC (el orden en que se registraron)
    List<Producto> findAllByOrderByIdAsc();

    // SELECT COUNT(*) FROM productos WHERE marca_id = ?  (para no borrar marcas con productos)
    long countByMarcaId(Long marcaId);
}
