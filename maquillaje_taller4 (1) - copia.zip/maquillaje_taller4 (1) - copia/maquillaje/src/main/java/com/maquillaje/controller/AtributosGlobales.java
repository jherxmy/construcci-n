
package com.maquillaje.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.maquillaje.seguridad.SesionUsuario;
import com.maquillaje.service.CarritoService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/*
 * Comparte información con todas las vistas del sistema.
 * Permite mostrar las unidades del carrito y los datos del usuario conectado.
 */
@ControllerAdvice
public class AtributosGlobales {

    // Servicio encargado de consultar la información del carrito.
    private final CarritoService carritoService;

    // Constructor que recibe el servicio mediante inyección de dependencias.
    public AtributosGlobales(CarritoService carritoService) {
        this.carritoService = carritoService;
    }

    // Calcula cuántas unidades tiene el usuario en su carrito.
    @ModelAttribute("unidadesCarrito")
    public int unidadesCarrito(HttpServletRequest request) {

        // Obtiene la sesión actual sin crear una nueva si no existe.
        HttpSession sesion = request.getSession(false);

        // Obtiene el identificador del usuario que inició sesión.
        Long usuarioId = SesionUsuario.id(sesion);

        // Si no hay un usuario conectado, devuelve cero.
        // Si existe, consulta la cantidad de unidades de su carrito.
        return usuarioId == null ? 0 : carritoService.contarUnidades(usuarioId);
    }

    // Comprueba si el usuario ha iniciado sesión.
    @ModelAttribute("autenticado")
    public boolean autenticado(HttpServletRequest request) {
        return SesionUsuario.estaAutenticado(request.getSession(false));
    }

    // Comprueba si el usuario conectado tiene el rol de administrador.
    @ModelAttribute("esAdmin")
    public boolean esAdmin(HttpServletRequest request) {
        return SesionUsuario.esAdmin(request.getSession(false));
    }

    // Obtiene el nombre del usuario almacenado en la sesión.
    @ModelAttribute("nombreSesion")
    public String nombreSesion(HttpServletRequest request) {
        return SesionUsuario.nombre(request.getSession(false));
    }
}
