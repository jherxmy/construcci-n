package com.maquillaje.service;

/** Se lanza cuando se pide más cantidad de la que hay en inventario. El mensaje se muestra al usuario. */
public class StockInsuficienteException extends RuntimeException {

    public StockInsuficienteException(String mensaje) {
        super(mensaje);
    }
}
