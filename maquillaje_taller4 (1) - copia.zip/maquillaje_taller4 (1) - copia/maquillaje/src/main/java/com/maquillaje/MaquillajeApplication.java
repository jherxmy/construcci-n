package com.maquillaje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
/** Clase MaquillajeApplication: contiene la lógica y los datos propios de esta parte de la tienda. */
public class MaquillajeApplication {

    public static void main(String[] args) {
        SpringApplication.run(MaquillajeApplication.class, args);
    }
}
