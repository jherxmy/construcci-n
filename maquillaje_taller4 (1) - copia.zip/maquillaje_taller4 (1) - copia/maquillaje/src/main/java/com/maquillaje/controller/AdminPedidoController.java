
package com.maquillaje.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.maquillaje.model.EstadoPedido;
import com.maquillaje.service.PedidoService;

/*
 * Controlador encargado de administrar los pedidos.
 * Permite consultar todos los pedidos y modificar su estado.
 * Sus rutas están protegidas para usuarios con rol ADMIN.
 */
@Controller
@RequestMapping("/admin/pedidos")
public class AdminPedidoController {

    // Servicio encargado de consultar y gestionar los pedidos.
    private final PedidoService pedidoService;

    // Constructor que recibe el servicio mediante inyección de dependencias.
    public AdminPedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    // Consulta todos los pedidos y los envía a la vista del administrador.
    @GetMapping
    public String listar(Model model) {

        // Agrega la lista de pedidos para mostrarlos en la página.
        model.addAttribute("pedidos", pedidoService.listarTodos());

        // Envía todos los estados disponibles para utilizarlos en el formulario.
        model.addAttribute("estados", EstadoPedido.values());

        // Indica que se debe mostrar la página de administración de pedidos.
        return "admin-pedidos";
    }

    /*
     * Recibe el ID del pedido y el nuevo estado seleccionado.
     * Después actualiza la información y muestra un mensaje de confirmación.
     */
    @PostMapping("/{id}/estado")
    public String cambiarEstado(@PathVariable("id") Long id,
                                @RequestParam("estado") EstadoPedido estado,
                                RedirectAttributes redirect) {

        // Actualiza el estado del pedido utilizando el servicio.
        pedidoService.cambiarEstado(id, estado);

        // Envía un mensaje con el número del pedido y su nuevo estado.
        redirect.addFlashAttribute("mensaje", "Pedido N.° " + id + " actualizado: " + estado.getNombre());

        // Regresa al listado de pedidos.
        return "redirect:/admin/pedidos";
    }
}
