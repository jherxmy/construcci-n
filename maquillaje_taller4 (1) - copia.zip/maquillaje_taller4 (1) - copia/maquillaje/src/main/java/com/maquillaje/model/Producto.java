
package com.maquillaje.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * Representa la entidad Producto en la base de datos.
 * Almacena la información de los productos de maquillaje,
 * como nombre, categoría, precio, contenido, inventario,
 * marca, icono, imagen y tonos disponibles.
 */
@Entity
@Table(name = "productos")
public class Producto {

    /*
     * Lista de iconos disponibles para representar los productos.
     * Los nombres corresponden a las ilustraciones definidas en iconos.html.
     */
    public static final List<String> ICONOS = List.of(
            "base", "tubo", "compacto", "paleta", "rimel",
            "delineador", "labial", "brillo", "esmalte");

    // Color hexadecimal utilizado cuando el producto no tiene tonos definidos.
    public static final String TONO_POR_DEFECTO = "#f4a6b8";

    // Identificador único del producto, generado automáticamente por MySQL.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nombre y categoría a los que pertenece el producto.
    private String nombre;
    private String categoria;

    // Precio del producto expresado en pesos colombianos.
    private int precio;

    // Cantidad de contenido del producto, sin incluir la unidad de medida.
    @Column(name = "contenido_neto")
    private int contenido;

    // Unidad de medida del contenido. Por defecto se utiliza mililitros.
    private String unidad = "ml";

    /*
     * Almacena los tonos disponibles en un texto.
     * Ejemplo: "Rosa=#f4a6b8, Coral=#ff7f6e".
     * Puede quedar vacío si el producto no tiene tonos.
     */
    @Column(length = 500)
    private String color = "";

    // Cantidad de unidades disponibles del producto en el inventario.
    private int stock;

    /*
     * Relación muchos a uno: varios productos pueden pertenecer
     * a una misma marca.
     * La columna marca_id funciona como llave foránea.
     */
    @ManyToOne
    @JoinColumn(name = "marca_id")
    private Marca marca;

    // Icono que se utiliza para representar visualmente el producto.
    // Por defecto se asigna el icono de labial.
    private String icono = "labial";

    // Ruta o URL de la imagen del producto.
    // Este campo es opcional y permite almacenar hasta 500 caracteres.
    @Column(length = 500)
    private String imagen = "";

    // Constructor vacío requerido por JPA para crear objetos de esta entidad.
    public Producto() {
    }

    /*
     * Constructor que permite crear un producto con todos sus datos.
     * No recibe el ID porque este es generado automáticamente por MySQL.
     */
    public Producto(String nombre, String categoria, int precio, int contenido, String unidad,
                    int stock, Marca marca, String icono, String imagen, String color) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.contenido = contenido;
        this.unidad = unidad;
        this.stock = stock;
        this.marca = marca;
        this.icono = icono;
        this.imagen = imagen;
        this.color = color;
    }

    /*
     * Devuelve el contenido del producto junto con su unidad de medida.
     * Ejemplo: si contenido es 30 y unidad es "ml", devuelve "30 ml".
     */
    public String getContenidoNeto() {
        return contenido + " " + unidad;
    }

    /*
     * Convierte el texto almacenado en el atributo color
     * en una lista de objetos Tono.
     */
    public List<Tono> getTonos() {
        return Tono.desdeTexto(color);
    }

    /*
     * Obtiene el código hexadecimal del primer tono disponible.
     * Si el producto no tiene tonos, devuelve el color predeterminado.
     */
    public String getTonoInicial() {
        List<Tono> tonos = getTonos();
        return tonos.isEmpty() ? TONO_POR_DEFECTO : tonos.get(0).getHex();
    }

    /*
     * Devuelve el texto de los tonos del producto.
     * Si el atributo color es null, devuelve una cadena vacía.
     */
    public String getTonosTexto() {
        return color == null ? "" : color;
    }

    /*
     * Busca un tono utilizando su nombre.
     * Si encuentra una coincidencia, devuelve ese tono.
     * Si no lo encuentra, devuelve el primero disponible.
     * Si no existen tonos, devuelve null.
     */
    public Tono buscarTono(String nombreTono) {
        List<Tono> tonos = getTonos();

        // Comprueba si el producto tiene tonos disponibles.
        if (tonos.isEmpty()) {
            return null;
        }

        // Recorre la lista para buscar el tono solicitado.
        for (Tono tono : tonos) {
            if (tono.getNombre().equalsIgnoreCase(nombreTono)) {
                return tono;
            }
        }

        // Si no encuentra el nombre, devuelve el primer tono de la lista.
        return tonos.get(0);
    }

    // Getter: permite consultar el identificador del producto.
    public Long getId() { return id; }

    // Getter y setter del nombre del producto.
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    // Getter y setter de la categoría.
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    // Getter y setter del precio.
    public int getPrecio() { return precio; }
    public void setPrecio(int precio) { this.precio = precio; }

    // Getter y setter de la cantidad de contenido.
    public int getContenido() { return contenido; }
    public void setContenido(int contenido) { this.contenido = contenido; }

    // Getter y setter de la unidad de medida.
    public String getUnidad() { return unidad; }
    public void setUnidad(String unidad) { this.unidad = unidad; }

    // Getter y setter del texto que contiene los tonos del producto.
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    // Getter y setter de las unidades disponibles en inventario.
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    // Getter y setter de la marca asociada al producto.
    public Marca getMarca() { return marca; }
    public void setMarca(Marca marca) { this.marca = marca; }

    // Getter y setter del icono utilizado para representar el producto.
    public String getIcono() { return icono; }
    public void setIcono(String icono) { this.icono = icono; }

    // Getter y setter de la imagen del producto.
    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }
}
