
package com.maquillaje.service;

// Permite cifrar y comprobar contraseñas utilizando BCrypt.
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

// Identifica esta clase como un servicio de Spring.
import org.springframework.stereotype.Service;

// Permite ejecutar operaciones dentro de una transacción.
import org.springframework.transaction.annotation.Transactional;

import com.maquillaje.model.Rol;
import com.maquillaje.model.Usuario;
import com.maquillaje.repository.UsuarioRepository;

/**
 * Servicio encargado de administrar los usuarios.
 * Permite registrar nuevas cuentas, autenticar usuarios
 * y comprobar si un nombre de usuario ya existe.
 */
@Service
public class UsuarioService {

    // Repositorio encargado de guardar y consultar los usuarios.
    private final UsuarioRepository repositorio;

    // BCrypt protege las contraseñas mediante un hash.
    // Cada contraseña genera un resultado diferente gracias a una sal aleatoria.
    // No se puede recuperar la contraseña original a partir del hash.
    private final BCryptPasswordEncoder codificador = new BCryptPasswordEncoder();

    // Constructor que recibe el repositorio mediante inyección de dependencias.
    public UsuarioService(UsuarioRepository repositorio) {
        this.repositorio = repositorio;
    }

    /**
     * REGISTRAR USUARIO:
     * Valida los datos recibidos y guarda el nuevo usuario
     * con su contraseña protegida mediante BCrypt.
     *
     * @Transactional permite que la operación de registro
     * se ejecute dentro de una transacción.
     */
    @Transactional
    public Usuario registrar(String nombreCompleto, String usuario, String correo,
                             String contrasena, Rol rol) {

        // Si el nombre completo es null, lo reemplaza por un texto vacío.
        // Si tiene contenido, elimina los espacios al principio y al final.
        nombreCompleto = nombreCompleto == null ? "" : nombreCompleto.trim();

        // Realiza la misma limpieza para el nombre de usuario.
        usuario = usuario == null ? "" : usuario.trim();

        // Elimina los espacios al principio y al final del correo.
        correo = correo == null ? "" : correo.trim();

        // Si la contraseña es null, la reemplaza por un texto vacío.
        // No utiliza trim() para no modificar la contraseña original.
        contrasena = contrasena == null ? "" : contrasena;

        // Comprueba que el nombre completo tenga al menos 3 caracteres.
        if (nombreCompleto.length() < 3) {
            throw new IllegalArgumentException("Escribe tu nombre completo.");
        }

        // Valida el nombre de usuario mediante una expresión regular.
        // Permite letras, números, puntos, guiones y guiones bajos.
        // También exige entre 3 y 30 caracteres.
        if (!usuario.matches("[A-Za-z0-9._-]{3,30}")) {
            throw new IllegalArgumentException(
                    "El usuario debe tener entre 3 y 30 caracteres (letras, números, punto, guion o guion bajo).");
        }

        // Comprueba que el correo tenga una estructura básica válida.
        // Exige texto antes y después de @ y un punto en el dominio.
        if (!correo.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
            throw new IllegalArgumentException("Escribe un correo válido, por ejemplo nombre@correo.com.");
        }

        // Comprueba que la contraseña tenga al menos 6 caracteres.
        if (contrasena.length() < 6) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres.");
        }

        // Comprueba si ya existe un usuario con ese nombre,
        // sin distinguir entre letras mayúsculas y minúsculas.
        if (repositorio.existsByUsuarioIgnoreCase(usuario)) {
            throw new IllegalArgumentException("Ese nombre de usuario ya está en uso.");
        }

        // Comprueba si el correo ya está registrado,
        // también ignorando las diferencias entre mayúsculas y minúsculas.
        if (repositorio.existsByCorreoIgnoreCase(correo)) {
            throw new IllegalArgumentException("Ya existe una cuenta con ese correo.");
        }

        // Crea el nuevo usuario con los datos validados.
        // codificador.encode() genera el hash BCrypt de la contraseña.
        Usuario nuevo = new Usuario(nombreCompleto, usuario, correo, codificador.encode(contrasena), rol);

        // Guarda el nuevo usuario en la base de datos y lo retorna.
        return repositorio.save(nuevo);
    }

    /**
     * AUTENTICAR USUARIO:
     * Busca una cuenta mediante su nombre de usuario o correo
     * y comprueba que la contraseña ingresada sea correcta.
     *
     * Retorna el usuario si los datos coinciden o null si no coinciden.
     */
    public Usuario autenticar(String identificador, String contrasena) {

        // Comprueba que los datos necesarios no sean null
        // y que el identificador no esté vacío.
        if (identificador == null || contrasena == null || identificador.isBlank()) {
            return null;
        }

        // Elimina los espacios al principio y al final del identificador.
        String dato = identificador.trim();

        // Primero busca el usuario por su nombre de usuario.
        // Si no lo encuentra, intenta buscarlo por correo.
        // Si tampoco existe, retorna null.
        Usuario encontrado = repositorio.findByUsuarioIgnoreCase(dato)
                .or(() -> repositorio.findByCorreoIgnoreCase(dato))
                .orElse(null);

        // Comprueba que el usuario exista y que la contraseña ingresada
        // coincida con el hash BCrypt almacenado en la base de datos.
        if (encontrado != null && codificador.matches(contrasena, encontrado.getContrasena())) {

            // Si los datos son correctos, retorna el usuario autenticado.
            return encontrado;
        }

        // Si el usuario no existe o la contraseña es incorrecta, retorna null.
        return null;
    }

    // ---------- Comprobar existencia de usuario ----------

    // Recibe un nombre de usuario y consulta si ya está registrado.
    public boolean existeUsuario(String usuario) {

        // Retorna true si existe y false si no existe.
        return repositorio.existsByUsuarioIgnoreCase(usuario);
    }
}
