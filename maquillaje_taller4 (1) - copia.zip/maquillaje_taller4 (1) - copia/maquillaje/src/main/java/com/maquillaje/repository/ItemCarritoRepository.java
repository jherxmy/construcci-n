
package com.maquillaje.repository;

// Permite trabajar con listas de resultados.
import java.util.List;

// Permite representar resultados que pueden existir o no.
import java.util.Optional;

// Interfaz de Spring Data JPA que proporciona operaciones para la base de datos.
import org.springframework.data.jpa.repository.JpaRepository;

import com.maquillaje.model.ItemCarrito;

/**
 * Repositorio encargado de comunicarse con la tabla "carrito".
 * Permite consultar, contar y eliminar los productos
 * que se encuentran en el carrito de cada usuario.
 *
 * Extiende JpaRepository para obtener operaciones
 * de persistencia sin tener que implementarlas manualmente.
 */
public interface ItemCarritoRepository extends JpaRepository<ItemCarrito, Long> {

    // Busca los productos del carrito de un usuario específico.
    // Los resultados se organizan por el identificador de línea en orden ascendente.
    // Equivale a: SELECT * FROM carrito WHERE usuario_id = ? ORDER BY linea_id
    List<ItemCarrito> findByUsuarioIdOrderByLineaIdAsc(Long usuarioId);

    // Busca una línea del carrito verificando que pertenezca al usuario indicado.
    // Evita consultar o modificar accidentalmente líneas del carrito de otro usuario.
    // Optional permite representar el caso en que no se encuentre ningún resultado.
    Optional<ItemCarrito> findByLineaIdAndUsuarioId(Long lineaId, Long usuarioId);

    // Cuenta cuántas líneas de productos tiene el carrito de un usuario.
    // Equivale a: SELECT COUNT(*) FROM carrito WHERE usuario_id = ?
    long countByUsuarioId(Long usuarioId);

    // Elimina todos los registros del carrito que pertenecen al usuario indicado.
    // Se utiliza, por ejemplo, después de completar una compra.
    // Equivale a: DELETE FROM carrito WHERE usuario_id = ?
    void deleteByUsuarioId(Long usuarioId);

    // Elimina las líneas del carrito que contienen un producto específico.
    // Es útil cuando un producto se elimina del catálogo.
    // Equivale a: DELETE FROM carrito WHERE producto_id = ?
    void deleteByProductoId(Long productoId);
}
