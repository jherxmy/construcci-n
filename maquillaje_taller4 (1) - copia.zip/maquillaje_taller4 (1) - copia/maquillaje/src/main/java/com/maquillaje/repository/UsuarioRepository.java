package com.maquillaje.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maquillaje.model.Usuario;

/** REPOSITORIO: se comunica con la tabla "usuarios". */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // SELECT * FROM usuarios WHERE LOWER(usuario) = LOWER(?)
    Optional<Usuario> findByUsuarioIgnoreCase(String usuario);

    // SELECT * FROM usuarios WHERE LOWER(correo) = LOWER(?)
    Optional<Usuario> findByCorreoIgnoreCase(String correo);

    boolean existsByUsuarioIgnoreCase(String usuario);

    boolean existsByCorreoIgnoreCase(String correo);
}
