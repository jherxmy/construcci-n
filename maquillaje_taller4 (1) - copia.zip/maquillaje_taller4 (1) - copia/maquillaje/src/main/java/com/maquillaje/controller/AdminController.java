
package com.maquillaje.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.maquillaje.model.Marca;
import com.maquillaje.model.Producto;
import com.maquillaje.model.Tono;
import com.maquillaje.service.CarritoService;
import com.maquillaje.service.CatalogoService;

/*
 * Controlador encargado de administrar los productos.
 * Permite registrar, consultar, editar y eliminar productos.
 * Sus rutas están protegidas para usuarios con rol ADMIN.
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    // Servicios que permiten gestionar el catálogo y el carrito de compras.
    private final CatalogoService catalogoService;
    private final CarritoService carritoService;

    // Constructor que recibe los servicios mediante inyección de dependencias.
    public AdminController(CatalogoService catalogoService, CarritoService carritoService) {
        this.catalogoService = catalogoService;
        this.carritoService = carritoService;
    }

    // Muestra el listado de productos y un formulario vacío para registrar uno nuevo.
    @GetMapping
    public String listar(Model model) {
        return mostrar(model, new Producto(), false);
    }

    // Busca el producto por su ID y carga sus datos en el formulario de edición.
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable("id") Long id, Model model) {
        Producto producto = catalogoService.buscarProducto(id);

        // Si el producto no existe, regresa al panel principal.
        if (producto == null) {
            return "redirect:/admin";
        }

        return mostrar(model, producto, true);
    }

    /*
     * Método que prepara los datos necesarios para mostrar el panel.
     * También permite reutilizar el mismo formulario para registrar y editar.
     */
    private String mostrar(Model model, Producto formulario, boolean editando) {
        model.addAttribute("productos", catalogoService.listarProductos());
        model.addAttribute("marcas", catalogoService.listarMarcas());
        model.addAttribute("categorias", catalogoService.listarCategorias());
        model.addAttribute("iconos", Producto.ICONOS);
        model.addAttribute("form", formulario);
        model.addAttribute("editando", editando);

        // Indica a Spring que debe mostrar la vista admin.
        return "admin";
    }

    /*
     * Recibe los datos del formulario para registrar o actualizar un producto.
     * Si llega un ID, actualiza el producto existente; si no, crea uno nuevo.
     */
    @PostMapping("/guardar")
    public String guardar(@RequestParam(name = "id", required = false) Long id,
                          @RequestParam("nombre") String nombre,
                          @RequestParam("categoria") String categoria,
                          @RequestParam("precio") int precio,
                          @RequestParam("contenido") int contenido,
                          @RequestParam("unidad") String unidad,
                          @RequestParam("stock") int stock,
                          @RequestParam("marcaId") Long marcaId,
                          @RequestParam("icono") String icono,
                          @RequestParam(name = "tonos", defaultValue = "") String tonos,
                          @RequestParam(name = "imagen", defaultValue = "") String imagen,
                          RedirectAttributes redirect) {

        // Define a dónde regresar dependiendo de si se está registrando o editando.
        String volver = (id == null) ? "redirect:/admin" : "redirect:/admin/editar/" + id;

        // Busca la marca seleccionada para comprobar que exista.
        Marca marca = catalogoService.buscarMarca(marcaId);

        // Valida que los campos obligatorios tengan datos y que los valores sean correctos.
        if (nombre.isBlank() || categoria.isBlank() || precio <= 0 || contenido <= 0 || stock < 0 || marca == null) {
            redirect.addFlashAttribute("error",
                    "Revisa los datos: nombre, categoría, marca, precio y contenido son obligatorios, y el stock no puede ser negativo.");
            return volver;
        }

        // Crea un producto nuevo o busca el producto que se desea actualizar.
        Producto producto = (id == null) ? new Producto() : catalogoService.buscarProducto(id);

        // Si no encuentra el producto que se intenta editar, regresa al panel.
        if (producto == null) {
            return "redirect:/admin";
        }

        // Asigna al producto los datos recibidos desde el formulario.
        producto.setNombre(nombre.trim());
        producto.setCategoria(categoria.trim());
        producto.setPrecio(precio);
        producto.setContenido(contenido);
        producto.setUnidad(unidad);
        producto.setStock(stock);
        producto.setMarca(marca);
        producto.setIcono(icono);
        producto.setImagen(imagen.trim());

        // Normaliza los tonos antes de guardarlos en el campo color.
        producto.setColor(Tono.normalizar(tonos));   // Ejemplo: Rosa=#f4a6b8, Coral=#ff7f6e

        // Guarda el producto en la base de datos: lo inserta o actualiza según corresponda.
        catalogoService.guardar(producto);

        // Si es un producto nuevo, muestra un mensaje de registro.
        if (id == null) {
            redirect.addFlashAttribute("mensaje", "Producto registrado: " + producto.getNombre());
        } else {
            // Actualiza la información del producto en las líneas de los carritos existentes.
            carritoService.sincronizarProducto(producto.getId());
            redirect.addFlashAttribute("mensaje", "Producto actualizado: " + producto.getNombre());
        }

        return "redirect:/admin";
    }

    // Elimina un producto y lo retira de los carritos donde se encuentre.
    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable("id") Long id, RedirectAttributes redirect) {
        carritoService.eliminarProducto(id);
        catalogoService.eliminar(id);

        // Envía un mensaje para informar que la eliminación se realizó.
        redirect.addFlashAttribute("mensaje", "Producto eliminado");

        return "redirect:/admin";
    }
}
