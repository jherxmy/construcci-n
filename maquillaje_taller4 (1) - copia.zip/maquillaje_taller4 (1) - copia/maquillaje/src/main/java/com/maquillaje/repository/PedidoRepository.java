package com.maquillaje.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maquillaje.model.Pedido;

/** REPOSITORIO: se comunica con la tabla "pedidos". */
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    // Todos los pedidos, los más recientes primero (panel del administrador)
    List<Pedido> findAllByOrderByIdDesc();

    // Los pedidos de un cliente, los más recientes primero (su historial de compras)
    List<Pedido> findByUsuarioIdOrderByIdDesc(Long usuarioId);
}
