
package com.maquillaje.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*
 * Representa la entidad Marca en la base de datos.
 * Almacena la información de cada marca de maquillaje,
 * incluyendo su nombre, país, descripción y logo.
 */
@Entity
@Table(name = "marcas")
public class Marca {

    // Identificador único de la marca.
    // MySQL genera automáticamente este valor mediante AUTO_INCREMENT.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nombre de la marca de maquillaje.
    private String nombre;

    // País de origen de la marca.
    private String pais;

    // Descripción breve de la marca.
    // Se establece una longitud máxima de 500 caracteres para esta columna.
    @Column(length = 500)
    private String descripcion;

    // Guarda la ruta o dirección de la imagen del logo de la marca.
    // La columna permite almacenar hasta 500 caracteres.
    @Column(length = 500)
    private String logo;

    // Constructor vacío requerido por JPA para crear objetos de esta entidad.
    public Marca() {
    }

    /*
     * Constructor que permite crear una marca con sus datos principales.
     * No recibe el ID porque este es generado automáticamente por MySQL.
     */
    public Marca(String nombre, String pais, String descripcion, String logo) {
        this.nombre = nombre;
        this.pais = pais;
        this.descripcion = descripcion;
        this.logo = logo;
    }

    // Getter: permite consultar el identificador de la marca.
    public Long getId() { return id; }

    // Getter y setter del nombre de la marca.
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    // Getter y setter del país de origen.
    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }

    // Getter y setter de la descripción.
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    // Getter y setter de la ruta o dirección del logo.
    public String getLogo() { return logo; }
    public void setLogo(String logo) { this.logo = logo; }
}
