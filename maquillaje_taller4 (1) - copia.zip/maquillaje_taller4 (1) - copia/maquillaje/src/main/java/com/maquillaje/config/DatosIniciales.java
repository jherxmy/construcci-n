
package com.maquillaje.config;

import java.util.Map;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.maquillaje.model.Marca;
import com.maquillaje.model.Producto;
import com.maquillaje.model.Rol;
import com.maquillaje.repository.MarcaRepository;
import com.maquillaje.repository.ProductoRepository;
import com.maquillaje.service.UsuarioService;

/**
 * Clase encargada de cargar los datos iniciales de la tienda.
 * Se ejecuta automáticamente al iniciar la aplicación.
 * Crea las marcas, los productos y el administrador si no existen.
 */
@Component
public class DatosIniciales implements CommandLineRunner {

    // Credenciales utilizadas para crear el administrador inicial.
    private static final String ADMIN_USUARIO = "admin";
    private static final String ADMIN_CORREO = "admin@rosaaurora.com";
    private static final String ADMIN_CONTRASENA = "admin123";

    // Relaciona el nombre de cada producto con la ruta de su imagen local.
    private static final Map<String, String> IMAGENES_LOCALES = Map.of(
            "Base líquida mate", "/img/productos/base-liquida-mate.svg",
            "Corrector de ojeras", "/img/productos/corrector-de-ojeras.svg",
            "Polvo compacto translúcido", "/img/productos/polvo-compacto-translucido.svg",
            "Rubor en polvo", "/img/productos/rubor-en-polvo.svg",
            "Paleta de sombras 12 tonos", "/img/productos/paleta-de-sombras.svg",
            "Máscara de pestañas", "/img/productos/mascara-de-pestanas.svg",
            "Delineador líquido", "/img/productos/delineador-liquido.svg",
            "Labial líquido mate", "/img/productos/labial-liquido-mate.svg",
            "Brillo labial", "/img/productos/brillo-labial.svg",
            "Esmalte de uñas", "/img/productos/esmalte-de-unas.svg");

    // Dirección base de las imágenes alojadas en Unsplash.
    private static final String HOST_UNSPLASH = "https://images.unsplash.com/";

    // Repositorios y servicio necesarios para gestionar las marcas,
    // los productos y los usuarios de la aplicación.
    private final MarcaRepository marcaRepositorio;
    private final ProductoRepository productoRepositorio;
    private final UsuarioService usuarioService;

    // Constructor que recibe las dependencias mediante inyección de Spring.
    public DatosIniciales(MarcaRepository marcaRepositorio, ProductoRepository productoRepositorio,
                          UsuarioService usuarioService) {
        this.marcaRepositorio = marcaRepositorio;
        this.productoRepositorio = productoRepositorio;
        this.usuarioService = usuarioService;
    }

    // Método que Spring ejecuta automáticamente al iniciar la aplicación.
    @Override
    public void run(String... args) {

        // Verifica y registra las marcas y los productos iniciales.
        crearMarcasYProductos();

        // Comprueba que los productos tengan sus imágenes locales.
        usarImagenesLocales();

        // Verifica si existe el administrador y lo crea si es necesario.
        crearAdministrador();
    }

    /**
     * Recorre los productos registrados y verifica sus imágenes.
     * Si no tienen imagen o utilizan una de Unsplash, les asigna
     * la imagen local correspondiente.
     */
    private void usarImagenesLocales() {

        // Obtiene todos los productos almacenados en la base de datos.
        for (Producto producto : productoRepositorio.findAll()) {

            // Busca la imagen local correspondiente al nombre del producto.
            String local = IMAGENES_LOCALES.get(producto.getNombre());

            // Obtiene la imagen que tiene actualmente el producto.
            String actual = producto.getImagen();

            // Comprueba si no tiene imagen, está vacía o utiliza Unsplash.
            boolean sinFotoLocal = actual == null || actual.isBlank() || actual.startsWith(HOST_UNSPLASH);

            // Si existe una imagen local y necesita reemplazarse, la asigna.
            if (local != null && sinFotoLocal) {
                producto.setImagen(local);

                // Guarda el cambio en la base de datos.
                productoRepositorio.save(producto);
            }
        }
    }

    /**
     * Comprueba si existe el usuario administrador.
     * Si no está registrado, crea su cuenta con el rol ADMIN.
     */
    private void crearAdministrador() {

        // Verifica que el nombre de usuario todavía no exista.
        if (!usuarioService.existeUsuario(ADMIN_USUARIO)) {

            // Registra al administrador con sus datos y su rol correspondiente.
            usuarioService.registrar("Administrador Rosa Aurora", ADMIN_USUARIO, ADMIN_CORREO,
                    ADMIN_CONTRASENA, Rol.ADMIN);

            // Muestra las credenciales del administrador en la consola.
            System.out.println(">>> Administrador creado -> usuario: " + ADMIN_USUARIO
                    + " | contraseña: " + ADMIN_CONTRASENA);
        }
    }

    /**
     * Registra las cuatro marcas y los diez productos iniciales.
     * Antes verifica que las tablas estén vacías para evitar duplicados.
     */
    private void crearMarcasYProductos() {

        // Si alguna de las dos tablas ya tiene registros, no realiza la carga inicial.
        if (marcaRepositorio.count() > 0 || productoRepositorio.count() > 0) {
            return;
        }

        // ----- Marcas -----

        // Crea y guarda la marca Rosé Atelier.
        Marca rose = marcaRepositorio.save(new Marca("Rosé Atelier", "Francia",
                "Maquillaje de inspiración parisina con acabados suaves y luminosos.",
                "/img/marcas/rose-atelier.svg"));

        // Crea y guarda la marca Bloom Beauty.
        Marca bloom = marcaRepositorio.save(new Marca("Bloom Beauty", "Estados Unidos",
                "Fórmulas veganas y colores vibrantes pensados para todos los tonos de piel.",
                "/img/marcas/bloom-beauty.svg"));

        // Crea y guarda la marca Luna Cosméticos.
        Marca luna = marcaRepositorio.save(new Marca("Luna Cosméticos", "Colombia",
                "Marca paisa con tonos cálidos y fórmulas de larga duración para piel latina.",
                "/img/marcas/luna-cosmeticos.svg"));

        // Crea y guarda la marca Seúl Glow.
        Marca seul = marcaRepositorio.save(new Marca("Seúl Glow", "Corea del Sur",
                "K-beauty de texturas ligeras y acabado glass skin que cuida mientras maquilla.",
                "/img/marcas/seul-glow.svg"));

        System.out.println(">>> Marcas insertadas: 4");

        // ----- Productos -----
        // Cada producto contiene nombre, categoría, precio, contenido,
        // unidad de medida, stock, marca, icono, imagen y tonos disponibles.

        // Producto de rostro asociado a Luna Cosméticos.
        productoRepositorio.save(new Producto("Base líquida mate", "Rostro", 65000, 30, "ml", 25, luna, "base",
                "/img/productos/base-liquida-mate.svg",
                "Marfil=#f3dcc8, Beige=#e8c4a0, Canela=#c99a74, Moka=#9a6b4b"));

        // Producto de rostro asociado a Bloom Beauty.
        productoRepositorio.save(new Producto("Corrector de ojeras", "Rostro", 38000, 6, "ml", 30, bloom, "tubo",
                "/img/productos/corrector-de-ojeras.svg",
                "Claro=#f1d3b8, Medio=#dcb08a, Oscuro=#b98a66"));

        // Producto de rostro asociado a Rosé Atelier.
        productoRepositorio.save(new Producto("Polvo compacto translúcido", "Rostro", 42000, 10, "g", 20, rose, "compacto",
                "/img/productos/polvo-compacto-translucido.svg",
                "Translúcido=#f5e6d8"));

        // Producto de rostro asociado a Seúl Glow.
        productoRepositorio.save(new Producto("Rubor en polvo", "Rostro", 35000, 5, "g", 18, seul, "compacto",
                "/img/productos/rubor-en-polvo.svg",
                "Rosa durazno=#f4a28c, Rosa palo=#e58ca0, Fucsia suave=#d96a96"));

        // Producto de ojos asociado a Rosé Atelier.
        productoRepositorio.save(new Producto("Paleta de sombras 12 tonos", "Ojos", 85000, 12, "g", 15, rose, "paleta",
                "/img/productos/paleta-de-sombras.svg",
                "Rosé nudes=#d8a39d, Atardecer=#e0907a, Berry=#a64d79"));

        // Producto de ojos asociado a Bloom Beauty.
        productoRepositorio.save(new Producto("Máscara de pestañas", "Ojos", 45000, 9, "ml", 40, bloom, "rimel",
                "/img/productos/mascara-de-pestanas.svg",
                "Negro intenso=#2a1f27"));

        // Producto de ojos asociado a Seúl Glow.
        productoRepositorio.save(new Producto("Delineador líquido", "Ojos", 32000, 3, "ml", 35, seul, "delineador",
                "/img/productos/delineador-liquido.svg",
                "Negro=#2a1f27, Café=#6b4233"));

        // Producto de labios asociado a Luna Cosméticos.
        productoRepositorio.save(new Producto("Labial líquido mate", "Labios", 38000, 5, "ml", 50, luna, "labial",
                "/img/productos/labial-liquido-mate.svg",
                "Rosa nude=#d99a94, Rojo cereza=#c2243f, Fucsia=#d6336c, Vino=#7b1e3a"));

        // Producto de labios asociado a Seúl Glow.
        productoRepositorio.save(new Producto("Brillo labial", "Labios", 28000, 4, "ml", 45, seul, "brillo",
                "/img/productos/brillo-labial.svg",
                "Transparente=#fbd5dc, Rosa=#f7a1b8, Coral=#ff8f7a"));

        // Producto de uñas asociado a Bloom Beauty.
        productoRepositorio.save(new Producto("Esmalte de uñas", "Uñas", 18000, 12, "ml", 60, bloom, "esmalte",
                "/img/productos/esmalte-de-unas.svg",
                "Rosa pastel=#f9c5d1, Rojo pasión=#d0283f, Lila=#c9a7e8, Nude=#e6bfae"));

        // Confirma en la consola que se registraron los diez productos.
        System.out.println(">>> Productos insertados: 10");
    }

}
