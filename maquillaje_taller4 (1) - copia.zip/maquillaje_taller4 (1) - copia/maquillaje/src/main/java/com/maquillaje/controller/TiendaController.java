
package com.maquillaje.controller;

import java.nio.charset.StandardCharsets;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.maquillaje.model.MetodoEnvio;
import com.maquillaje.model.Pedido;
import com.maquillaje.model.Producto;
import com.maquillaje.seguridad.SesionUsuario;
import com.maquillaje.service.CarritoService;
import com.maquillaje.service.CatalogoService;
import com.maquillaje.service.PedidoService;
import com.maquillaje.service.StockInsuficienteException;

import jakarta.servlet.http.HttpSession;

/*
 * Controlador encargado de las funciones principales de la tienda.
 * Permite consultar productos, gestionar el carrito, realizar compras
 * y consultar el historial de pedidos de los clientes.
 */
@Controller
public class TiendaController {

    // Servicios encargados de gestionar el catálogo, el carrito y los pedidos.
    private final CatalogoService catalogoService;
    private final CarritoService carritoService;
    private final PedidoService pedidoService;

    // Constructor que recibe los servicios mediante inyección de dependencias.
    public TiendaController(CatalogoService catalogoService, CarritoService carritoService,
                            PedidoService pedidoService) {
        this.catalogoService = catalogoService;
        this.carritoService = carritoService;
        this.pedidoService = pedidoService;
    }

    // ---------- Catálogo ----------

    // Consulta los productos, marcas y categorías para mostrarlos en la página principal.
    @GetMapping("/")
    public String catalogo(Model model) {
        model.addAttribute("productos", catalogoService.listarProductos());
        model.addAttribute("marcas", catalogoService.listarMarcas());
        model.addAttribute("categorias", catalogoService.listarCategorias());

        // Carga la vista principal de la tienda.
        return "index";
    }

    // ---------- Agregar al carrito ----------

    /*
     * Permite agregar productos al carrito sin recargar la página.
     * Se comunica con JavaScript mediante una solicitud fetch.
     */
    @PostMapping(value = "/carrito/agregar/{id}", headers = "X-Requested-With=fetch")
    @ResponseBody
    public ResponseEntity<String> agregarSinRecargar(@PathVariable("id") Long id,
                                                     @RequestParam(name = "tono", required = false) String tono,
                                                     @RequestParam(name = "cantidad", defaultValue = "1") int cantidad,
                                                     HttpSession sesion) {

        // Obtiene el ID del usuario que inició sesión.
        Long usuarioId = SesionUsuario.id(sesion);

        // Busca el producto seleccionado en el catálogo.
        Producto producto = catalogoService.buscarProducto(id);

        try {
            // Comprueba que el producto exista antes de agregarlo.
            if (producto != null) {
                carritoService.agregar(usuarioId, producto, tono, cantidad);
            }

            // Devuelve la cantidad actual de unidades que tiene el carrito.
            return texto(HttpStatus.OK, String.valueOf(carritoService.contarUnidades(usuarioId)));

        } catch (StockInsuficienteException e) {

            // Devuelve el error 409 cuando no hay suficientes unidades disponibles.
            return texto(HttpStatus.CONFLICT, e.getMessage());
        }
    }

    /*
     * Construye una respuesta de texto para el navegador.
     * Recibe el estado HTTP y el contenido que se desea devolver.
     */
    private ResponseEntity<String> texto(HttpStatus estado, String cuerpo) {
        return ResponseEntity.status(estado)
                .contentType(new MediaType("text", "plain", StandardCharsets.UTF_8))
                .body(cuerpo);
    }

    /*
     * Método alternativo para agregar productos al carrito.
     * Se utiliza cuando JavaScript está desactivado y la página necesita recargarse.
     */
    @PostMapping("/carrito/agregar/{id}")
    public String agregar(@PathVariable("id") Long id,
                          @RequestParam(name = "tono", required = false) String tono,
                          @RequestParam(name = "cantidad", defaultValue = "1") int cantidad,
                          HttpSession sesion,
                          RedirectAttributes redirect) {

        // Busca el producto que el cliente desea agregar.
        Producto producto = catalogoService.buscarProducto(id);

        if (producto != null) {
            try {
                // Agrega el producto al carrito del usuario.
                carritoService.agregar(SesionUsuario.id(sesion), producto, tono, cantidad);

                // Muestra un mensaje confirmando que se agregó el producto.
                redirect.addFlashAttribute("mensaje", producto.getNombre() + " se agregó a tu carrito");

            } catch (StockInsuficienteException e) {

                // Informa si no hay suficientes unidades en el inventario.
                redirect.addFlashAttribute("error", e.getMessage());
            }
        }

        // Regresa al catálogo de la página principal.
        return "redirect:/#catalogo";
    }

    // ---------- Carrito ----------

    // Muestra los productos y los valores calculados del carrito del usuario.
    @GetMapping("/carrito")
    public String verCarrito(Model model, HttpSession sesion) {

        // Obtiene el ID del usuario y el método de envío seleccionado.
        Long usuarioId = SesionUsuario.id(sesion);
        MetodoEnvio envio = SesionUsuario.envio(sesion);

        // Envía los productos y los cálculos del carrito a la vista.
        model.addAttribute("items", carritoService.listarItems(usuarioId));
        model.addAttribute("subtotal", carritoService.calcularSubtotal(usuarioId));
        model.addAttribute("envio", envio);
        model.addAttribute("costoEnvio", carritoService.calcularCostoEnvio(usuarioId, envio));
        model.addAttribute("total", carritoService.calcularTotal(usuarioId, envio));
        model.addAttribute("vacio", carritoService.estaVacio(usuarioId));

        // Envía los métodos de envío disponibles para mostrarlos en el formulario.
        model.addAttribute("metodos", MetodoEnvio.values());

        return "carrito";
    }

    // Modifica la cantidad de unidades de un producto que ya está en el carrito.
    @PostMapping("/carrito/actualizar/{lineaId}")
    public String actualizar(@PathVariable("lineaId") Long lineaId,
                             @RequestParam("cantidad") int cantidad,
                             HttpSession sesion,
                             RedirectAttributes redirect) {
        try {
            // Actualiza la cantidad de la línea seleccionada del carrito.
            carritoService.actualizarCantidad(SesionUsuario.id(sesion), lineaId, cantidad);

        } catch (StockInsuficienteException e) {

            // Muestra un mensaje si la cantidad solicitada supera el inventario.
            redirect.addFlashAttribute("error", e.getMessage());
        }

        return "redirect:/carrito";
    }

    // Elimina un producto específico del carrito del usuario.
    @PostMapping("/carrito/eliminar/{lineaId}")
    public String eliminar(@PathVariable("lineaId") Long lineaId, HttpSession sesion) {
        carritoService.eliminar(SesionUsuario.id(sesion), lineaId);
        return "redirect:/carrito";
    }

    // Guarda el método de envío que seleccionó el cliente en su sesión.
    @PostMapping("/carrito/envio")
    public String cambiarEnvio(@RequestParam("envio") MetodoEnvio envio, HttpSession sesion) {
        SesionUsuario.guardarEnvio(sesion, envio);
        return "redirect:/carrito";
    }

    // ---------- Confirmar pedido ----------

    /*
     * Procesa la compra del cliente.
     * Verifica que el carrito tenga productos, valida la dirección
     * y solicita la generación del pedido.
     */
    @PostMapping("/comprar")
    public String comprar(@RequestParam("direccion") String direccion,
                          HttpSession sesion,
                          RedirectAttributes redirect) {

        // Obtiene el ID del usuario que está realizando la compra.
        Long usuarioId = SesionUsuario.id(sesion);

        // Evita continuar si el carrito está vacío.
        if (carritoService.estaVacio(usuarioId)) {
            return "redirect:/carrito";
        }

        // Comprueba que el cliente haya escrito una dirección de entrega.
        if (direccion.isBlank()) {
            redirect.addFlashAttribute("error", "Escribe la dirección de entrega.");
            return "redirect:/carrito";
        }

        try {
            // Genera el pedido con el usuario, la dirección y el método de envío.
            Pedido pedido = pedidoService.generarPedido(usuarioId, direccion.trim(), SesionUsuario.envio(sesion));

            // Restablece el método de envío para una próxima compra.
            SesionUsuario.guardarEnvio(sesion, MetodoEnvio.ESTANDAR);

            // Envía un mensaje indicando que la compra fue confirmada.
            redirect.addFlashAttribute("mensaje", "¡Pedido confirmado con éxito! Esta es tu confirmación 💖");

            // Redirige a los detalles del pedido para evitar repetir la compra al recargar la página.
            return "redirect:/pedidos/" + pedido.getId();

        } catch (StockInsuficienteException e) {

            // Informa que no hay inventario suficiente y que el pedido no pudo confirmarse.
            redirect.addFlashAttribute("error", e.getMessage() + " Ajusta tu carrito para poder confirmar el pedido.");

            return "redirect:/carrito";
        }
    }

    // ---------- Historial y confirmación ----------

    // Muestra el historial de compras del usuario que inició sesión.
    @GetMapping("/pedidos")
    public String historial(Model model, HttpSession sesion) {

        // Consulta los pedidos asociados al usuario actual.
        model.addAttribute("pedidos", pedidoService.listarDeUsuario(SesionUsuario.id(sesion)));

        return "pedidos";
    }

    // Busca y muestra los detalles de un pedido específico.
    @GetMapping("/pedidos/{id}")
    public String verPedido(@PathVariable("id") Long id, Model model, HttpSession sesion) {

        // Busca el pedido utilizando el ID recibido desde la dirección URL.
        Pedido pedido = pedidoService.buscarPorId(id);

        // Comprueba que el pedido exista y pertenezca al usuario que intenta consultarlo.
        if (pedido == null || !pedido.getUsuario().getId().equals(SesionUsuario.id(sesion))) {
            return "redirect:/pedidos";
        }

        // Envía la información del pedido a la página de confirmación.
        model.addAttribute("pedido", pedido);

        return "pedido";
    }
}
