
package com.maquillaje.model;

// Permite crear listas que pueden aumentar o disminuir de tamaño.
import java.util.ArrayList;
import java.util.List;

// Anotaciones de JPA para trabajar con objetos que se guardan en la base de datos.
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/**
 * Representa un tono o color disponible de un producto.
 * Almacena el nombre del tono y su código de color hexadecimal.
 *
 * @Embeddable indica que esta clase no tiene una tabla propia.
 * Sus atributos se guardan como columnas dentro de la tabla
 * de la entidad que utilice esta clase.
 */
@Embeddable
public class Tono {

    // Nombre del tono, por ejemplo: Rosa, Coral o Rojo.
    private String nombre;

    // Código hexadecimal que representa visualmente el color.
    @Column(name = "codigo_hex")
    private String hex;

    // Constructor vacío obligatorio para que JPA pueda crear objetos.
    public Tono() {
    }

    // Constructor que permite crear un tono indicando su nombre y código hexadecimal.
    public Tono(String nombre, String hex) {
        this.nombre = nombre;
        this.hex = hex;
    }

    // Retorna el nombre del tono.
    public String getNombre() {
        return nombre;
    }

    // Retorna el código hexadecimal del tono.
    public String getHex() {
        return hex;
    }

    // ---------- Métodos para convertir y organizar los tonos ----------

    /**
     * Convierte un texto con varios tonos en una lista de objetos Tono.
     * Ejemplo: "Rosa=#f4a6b8, Coral=#ff7f6e".
     */
    public static List<Tono> desdeTexto(String texto) {

        // Crea una lista vacía donde se almacenarán los tonos.
        List<Tono> tonos = new ArrayList<>();

        // Si el texto es nulo o está vacío, retorna la lista sin elementos.
        if (texto == null || texto.isBlank()) {
            return tonos;
        }

        // Divide el texto cada vez que encuentra una coma.
        for (String parte : texto.split(",")) {

            // Separa el nombre del tono y su código hexadecimal usando el signo igual.
            String[] datos = parte.split("=");

            // Obtiene el nombre del tono y elimina los espacios sobrantes.
            String nombre = datos[0].trim();

            // Si el nombre está vacío, pasa al siguiente elemento.
            if (nombre.isEmpty()) {
                continue;
            }

            // Obtiene el código hexadecimal si existe; de lo contrario, deja un texto vacío.
            String hex = datos.length > 1 ? datos[1].trim() : "";

            // Comprueba que el código tenga el formato hexadecimal correcto.
            // Si no es válido, utiliza el color predeterminado del producto.
            if (!hex.matches("#[0-9a-fA-F]{6}")) {
                hex = Producto.TONO_POR_DEFECTO;
            }

            // Crea un objeto Tono con el nombre y el color obtenidos.
            tonos.add(new Tono(nombre, hex));
        }

        // Retorna la lista con todos los tonos encontrados.
        return tonos;
    }

    /**
     * Convierte una lista de objetos Tono en un solo texto.
     * Ejemplo: "Rosa=#f4a6b8, Coral=#ff7f6e".
     */
    public static String aTexto(List<Tono> tonos) {

        // StringBuilder permite construir un texto agregando diferentes valores.
        StringBuilder texto = new StringBuilder();

        // Recorre todos los tonos que contiene la lista.
        for (Tono tono : tonos) {

            // Agrega una coma y un espacio antes de cada tono, excepto el primero.
            if (texto.length() > 0) {
                texto.append(", ");
            }

            // Agrega el nombre del tono, el signo igual y su código hexadecimal.
            texto.append(tono.getNombre()).append("=").append(tono.getHex());
        }

        // Retorna el texto construido.
        return texto.toString();
    }

    /**
     * Normaliza el texto ingresado por el administrador.
     * Convierte los datos en tonos, corrige colores inválidos
     * y vuelve a organizarlos en un texto uniforme.
     */
    public static String normalizar(String texto) {

        // Primero convierte el texto en una lista de tonos
        // y después vuelve a convertir esa lista en texto.
        return aTexto(desdeTexto(texto));
    }
}
