
package com.maquillaje.service;

// Permite trabajar con listas de elementos.
import java.util.List;

// Proporciona métodos para comparar objetos de manera segura, incluso si son null.
import java.util.Objects;

// Anotación que identifica esta clase como un servicio de Spring.
import org.springframework.stereotype.Service;

// Permite ejecutar operaciones dentro de una transacción de base de datos.
import org.springframework.transaction.annotation.Transactional;

import com.maquillaje.model.ItemCarrito;
import com.maquillaje.model.MetodoEnvio;
import com.maquillaje.model.Producto;
import com.maquillaje.model.Tono;
import com.maquillaje.model.Usuario;
import com.maquillaje.repository.ItemCarritoRepository;
import com.maquillaje.repository.UsuarioRepository;

/**
 * Servicio encargado de administrar el carrito de compras.
 * Guarda los productos en la tabla "carrito" de MySQL.
 *
 * Cada usuario tiene su propio carrito.
 * Valida el inventario al agregar productos y modificar cantidades.
 * Calcula el subtotal, el costo del envío y el total de la compra.
 */
@Service
public class CarritoService {

    // Define la cantidad máxima de unidades que se pueden agregar en una operación.
    private static final int MAXIMO_POR_AGREGADA = 20;

    // Repositorio utilizado para consultar y modificar los elementos del carrito.
    private final ItemCarritoRepository repositorio;

    // Repositorio utilizado para buscar los usuarios registrados.
    private final UsuarioRepository usuarioRepositorio;

    // ---------- Constructor e inyección de dependencias ----------

    // Recibe los repositorios necesarios para realizar las operaciones del carrito.
    public CarritoService(ItemCarritoRepository repositorio, UsuarioRepository usuarioRepositorio) {
        this.repositorio = repositorio;
        this.usuarioRepositorio = usuarioRepositorio;
    }

    // ---------- Listar ----------

    // Consulta todos los elementos del carrito de un usuario.
    // SELECT * FROM carrito WHERE usuario_id = ?
    public List<ItemCarrito> listarItems(Long usuarioId) {

        // Utiliza el repositorio para obtener los productos ordenados por línea.
        return repositorio.findByUsuarioIdOrderByLineaIdAsc(usuarioId);
    }

    /**
     * Calcula cuántas unidades de un producto tiene un usuario en su carrito,
     * sumando las cantidades de todos sus tonos.
     * El inventario se controla por producto, no por tono.
     */
    public int unidadesDeProducto(Long usuarioId, Long productoId) {

        // Inicializa el contador de unidades.
        int unidades = 0;

        // Recorre todos los elementos del carrito del usuario.
        for (ItemCarrito item : listarItems(usuarioId)) {

            // Comprueba si el producto del elemento actual coincide con el buscado.
            if (Objects.equals(item.getProducto().getId(), productoId)) {

                // Suma la cantidad de unidades de ese producto.
                unidades += item.getCantidad();
            }
        }

        // Retorna el total de unidades encontradas.
        return unidades;
    }

    // ---------- Agregar ----------

    /**
     * Agrega un producto al carrito con el tono seleccionado.
     * Si ya existe la misma combinación de producto y tono, aumenta su cantidad.
     * Comprueba que las unidades solicitadas no superen el inventario disponible.
     */
    @Transactional
    public void agregar(Long usuarioId, Producto producto, String nombreTono, int cantidad) {

        // Limita la cantidad: mínimo 1 y máximo MAXIMO_POR_AGREGADA (20).
        // Si se recibe un valor menor o mayor, lo ajusta automáticamente.
        cantidad = Math.max(1, Math.min(cantidad, MAXIMO_POR_AGREGADA));

        // ---------- VALIDACIÓN DE INVENTARIO ----------

        // Consulta cuántas unidades de este producto ya tiene el usuario en su carrito.
        int yaEnCarrito = unidadesDeProducto(usuarioId, producto.getId());

        // Comprueba que las unidades existentes más las nuevas no superen el stock.
        if (yaEnCarrito + cantidad > producto.getStock()) {

            // Si no hay suficientes unidades, lanza una excepción con el mensaje correspondiente.
            throw new StockInsuficienteException(mensajeStock(producto, yaEnCarrito));
        }

        // Busca el tono seleccionado dentro de los tonos disponibles del producto.
        Tono tono = producto.buscarTono(nombreTono);

        // Recorre los elementos que ya existen en el carrito del usuario.
        for (ItemCarrito item : listarItems(usuarioId)) {

            // Comprueba si el elemento actual corresponde al mismo producto.
            boolean mismoProducto = Objects.equals(item.getProducto().getId(), producto.getId());

            // Comprueba si también coincide el nombre del tono.
            if (mismoProducto && Objects.equals(nombre(item.getTono()), nombre(tono))) {

                // Si ya existe la misma combinación, suma las nuevas unidades.
                item.setCantidad(item.getCantidad() + cantidad);   // UPDATE

                // Guarda los cambios realizados en la base de datos.
                repositorio.save(item);

                // Termina el método porque el producto ya fue actualizado.
                return;
            }
        }

        // Busca al usuario en la base de datos mediante su identificador.
        // Si no existe, lanza una excepción indicando que el usuario ya no está disponible.
        Usuario usuario = usuarioRepositorio.findById(usuarioId)
                .orElseThrow(() -> new IllegalStateException("El usuario de la sesión ya no existe."));

        // Crea un nuevo elemento del carrito y lo guarda en la base de datos.
        repositorio.save(new ItemCarrito(usuario, producto, tono, cantidad));   // INSERT
    }

    // Obtiene el nombre de un tono.
    // Si el tono es null, retorna null para evitar un error.
    private String nombre(Tono tono) {
        return tono == null ? null : tono.getNombre();
    }

    /**
     * Construye el mensaje que se muestra cuando no hay suficientes
     * unidades disponibles de un producto.
     */
    public static String mensajeStock(Producto producto, int yaEnCarrito) {

        // Comprueba si el producto está completamente agotado.
        if (producto.getStock() <= 0) {

            // Retorna un mensaje indicando que el producto está agotado.
            return "«" + producto.getNombre() + "» está agotado.";
        }

        // Construye un mensaje indicando el nombre del producto y las unidades disponibles.
        String mensaje = "No hay stock suficiente de «" + producto.getNombre() + "»: solo quedan "
                + producto.getStock() + " unidades";

        // Si el usuario ya tiene unidades en su carrito, también las incluye en el mensaje.
        if (yaEnCarrito > 0) {
            mensaje += " y ya tienes " + yaEnCarrito + " en tu carrito";
        }

        // Retorna el mensaje completo.
        return mensaje + ".";
    }

    // ---------- Editar ----------

    // Actualiza la cantidad y el subtotal de una línea del carrito.
    // UPDATE carrito SET cantidad = ?, subtotal = ? WHERE linea_id = ?
    @Transactional
    public void actualizarCantidad(Long usuarioId, Long lineaId, int nuevaCantidad) {

        // Si la nueva cantidad es cero o negativa, elimina el producto del carrito.
        if (nuevaCantidad <= 0) {
            eliminar(usuarioId, lineaId);
            return;
        }

        // Busca la línea del carrito verificando que pertenezca al usuario indicado.
        // Si no existe, retorna null.
        ItemCarrito linea = repositorio.findByLineaIdAndUsuarioId(lineaId, usuarioId).orElse(null);

        // Si no se encuentra la línea, termina el método sin realizar cambios.
        if (linea == null) {
            return;
        }

        // Calcula las unidades del mismo producto que están en otras líneas del carrito.
        // Esto permite controlar el stock aunque el usuario tenga diferentes tonos.
        int enOtrasLineas = unidadesDeProducto(usuarioId, linea.getProducto().getId()) - linea.getCantidad();

        // Comprueba que las unidades de otras líneas más la nueva cantidad
        // no superen el inventario disponible.
        if (enOtrasLineas + nuevaCantidad > linea.getProducto().getStock()) {

            // Si supera el stock, lanza una excepción con el mensaje de advertencia.
            throw new StockInsuficienteException(mensajeStock(linea.getProducto(), enOtrasLineas));
        }

        // Actualiza la cantidad del elemento del carrito.
        linea.setCantidad(nuevaCantidad);

        // Guarda los cambios en la base de datos.
        repositorio.save(linea);
    }

    /**
     * Actualiza los datos de los productos que ya están en los carritos.
     * Se utiliza cuando el administrador modifica un producto del catálogo.
     */
    @Transactional
    public void sincronizarProducto(Long productoId) {

        // Obtiene todos los elementos registrados en los carritos.
        for (ItemCarrito item : repositorio.findAll()) {

            // Comprueba si el producto de la línea coincide con el producto actualizado.
            if (Objects.equals(item.getProducto().getId(), productoId)) {

                // Actualiza el nombre y el precio del producto dentro de la línea del carrito.
                item.actualizarDatosProducto();

                // Guarda los cambios en la base de datos.
                repositorio.save(item);
            }
        }
    }

    // ---------- Eliminar ----------

    // Elimina una línea del carrito únicamente si pertenece al usuario indicado.
    // DELETE FROM carrito WHERE linea_id = ? (solo si es de este usuario)
    @Transactional
    public void eliminar(Long usuarioId, Long lineaId) {

        // Busca la línea y, si existe, ejecuta su eliminación.
        repositorio.findByLineaIdAndUsuarioId(lineaId, usuarioId).ifPresent(repositorio::delete);
    }

    /**
     * Elimina de todos los carritos las líneas que contienen un producto.
     * Se utiliza cuando el administrador elimina un producto del catálogo.
     */
    @Transactional
    public void eliminarProducto(Long productoId) {

        // Llama al repositorio para eliminar las líneas asociadas al producto.
        repositorio.deleteByProductoId(productoId);
    }

    /**
     * Vacía completamente el carrito de un usuario.
     * Se utiliza después de completar una compra.
     */
    @Transactional
    public void vaciar(Long usuarioId) {

        // Elimina todos los elementos del carrito del usuario indicado.
        repositorio.deleteByUsuarioId(usuarioId);
    }

    // ---------- Cálculo de totales ----------

    // Calcula la cantidad total de unidades que tiene un usuario en su carrito.
    public int contarUnidades(Long usuarioId) {

        // Inicializa el contador.
        int unidades = 0;

        // Recorre los elementos del carrito.
        for (ItemCarrito item : listarItems(usuarioId)) {

            // Suma la cantidad de cada producto.
            unidades += item.getCantidad();
        }

        // Retorna el total de unidades.
        return unidades;
    }

    // ---------- Cálculo del subtotal ----------

    // Calcula el subtotal general sumando los subtotales de cada línea del carrito.
    // SUBTOTAL GENERAL: suma de la columna subtotal
    public int calcularSubtotal(Long usuarioId) {

        // Inicializa el subtotal general.
        int subtotal = 0;

        // Recorre todos los elementos del carrito.
        for (ItemCarrito item : listarItems(usuarioId)) {

            // Suma el subtotal de cada elemento.
            subtotal += item.getSubtotal();
        }

        // Retorna el subtotal de todos los productos.
        return subtotal;
    }

    /**
     * Calcula el costo del envío.
     * El envío solamente se cobra cuando el carrito contiene productos.
     */
    public int calcularCostoEnvio(Long usuarioId, MetodoEnvio envio) {

        // Si el carrito está vacío, el costo del envío es cero.
        // De lo contrario, retorna el costo del método de envío seleccionado.
        return estaVacio(usuarioId) ? 0 : envio.getCosto();
    }

    // Calcula el valor total de la compra sumando el subtotal y el costo del envío.
    // TOTAL: subtotal + envío
    public int calcularTotal(Long usuarioId, MetodoEnvio envio) {
        return calcularSubtotal(usuarioId) + calcularCostoEnvio(usuarioId, envio);
    }

    // Comprueba si el carrito de un usuario no tiene elementos.
    // SELECT COUNT(*) FROM carrito WHERE usuario_id = ? -> true si es 0
    public boolean estaVacio(Long usuarioId) {

        // Si el conteo de líneas es cero, retorna true; de lo contrario, false.
        return repositorio.countByUsuarioId(usuarioId) == 0;
    }
}
