
package com.maquillaje.service;

// Permite trabajar con fechas y horas.
import java.time.LocalDateTime;

// Permite crear listas dinámicas.
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Anotación para identificar esta clase como un servicio de Spring.
import org.springframework.stereotype.Service;

// Permite ejecutar operaciones dentro de una transacción.
import org.springframework.transaction.annotation.Transactional;

import com.maquillaje.model.DetallePedido;
import com.maquillaje.model.EstadoPedido;
import com.maquillaje.model.ItemCarrito;
import com.maquillaje.model.MetodoEnvio;
import com.maquillaje.model.Pedido;
import com.maquillaje.model.Producto;
import com.maquillaje.model.Usuario;
import com.maquillaje.repository.PedidoRepository;
import com.maquillaje.repository.ProductoRepository;
import com.maquillaje.repository.UsuarioRepository;

/**
 * Servicio encargado de administrar los pedidos.
 * Permite confirmar compras, descontar el inventario,
 * consultar el historial y actualizar los estados de los pedidos.
 */
@Service
public class PedidoService {

    // Repositorio encargado de guardar y consultar los pedidos.
    private final PedidoRepository repositorio;

    // Repositorio encargado de consultar y actualizar los productos.
    private final ProductoRepository productoRepositorio;

    // Repositorio encargado de buscar los usuarios.
    private final UsuarioRepository usuarioRepositorio;

    // Servicio que permite consultar y vaciar los carritos de compra.
    private final CarritoService carritoService;

    // ---------- Constructor e inyección de dependencias ----------

    // Spring proporciona automáticamente los repositorios y servicios necesarios.
    public PedidoService(PedidoRepository repositorio, ProductoRepository productoRepositorio,
                         UsuarioRepository usuarioRepositorio, CarritoService carritoService) {
        this.repositorio = repositorio;
        this.productoRepositorio = productoRepositorio;
        this.usuarioRepositorio = usuarioRepositorio;
        this.carritoService = carritoService;
    }

    /**
     * CONFIRMAR PEDIDO:
     * 1. Valida el inventario de todos los productos del carrito.
     * 2. Guarda el pedido y sus detalles en MySQL.
     * 3. Descuenta las unidades del inventario.
     * 4. Vacía el carrito del usuario.
     *
     * @Transactional permite que las operaciones se ejecuten
     * dentro de una misma transacción.
     */
    @Transactional
    public Pedido generarPedido(Long usuarioId, String direccion, MetodoEnvio envio) {

        // Busca al usuario que está realizando la compra.
        // Si no existe, lanza una excepción.
        Usuario usuario = usuarioRepositorio.findById(usuarioId)
                .orElseThrow(() -> new IllegalStateException("El usuario de la sesión ya no existe."));

        // Obtiene todos los productos que tiene el usuario en su carrito.
        List<ItemCarrito> items = carritoService.listarItems(usuarioId);

        // Comprueba que el carrito tenga productos antes de generar el pedido.
        if (items.isEmpty()) {
            throw new IllegalStateException("Tu carrito está vacío.");
        }

        // ---------- 1. VALIDAR INVENTARIO ----------

        // Mapa que almacena el identificador de cada producto
        // y la cantidad total solicitada de ese producto.
        // LinkedHashMap conserva el orden de inserción.
        Map<Long, Integer> pedidas = new LinkedHashMap<>();

        // Mapa que almacena los productos asociados a sus identificadores.
        Map<Long, Producto> productos = new LinkedHashMap<>();

        // Recorre todos los elementos del carrito.
        for (ItemCarrito item : items) {

            // Obtiene el identificador del producto actual.
            Long idProducto = item.getProducto().getId();

            // Suma la cantidad solicitada al total de ese producto.
            // Esto permite agrupar productos que tienen diferentes tonos.
            pedidas.merge(idProducto, item.getCantidad(), Integer::sum);

            // Guarda el producto si todavía no existe en el mapa.
            productos.putIfAbsent(idProducto, item.getProducto());
        }

        // Lista donde se almacenan los mensajes de productos sin stock suficiente.
        List<String> conflictos = new ArrayList<>();

        // Recorre los productos y las cantidades totales solicitadas.
        for (Map.Entry<Long, Integer> pedida : pedidas.entrySet()) {

            // Obtiene el producto utilizando su identificador.
            Producto producto = productos.get(pedida.getKey());

            // Comprueba si el inventario disponible es menor que la cantidad solicitada.
            if (producto.getStock() < pedida.getValue()) {

                // Agrega un mensaje indicando el problema de inventario.
                conflictos.add(CarritoService.mensajeStock(producto, 0)
                        + " (en tu carrito: " + pedida.getValue() + ")");
            }
        }

        // Si existe al menos un conflicto, no permite confirmar el pedido.
        if (!conflictos.isEmpty()) {

            // Une todos los mensajes de error en un solo texto
            // y lanza una excepción de inventario insuficiente.
            throw new StockInsuficienteException(String.join(" ", conflictos));
        }

        // ---------- 2. CREAR EL ENCABEZADO DEL PEDIDO ----------

        // Inicializa el subtotal general de los productos.
        int subtotal = 0;

        // Recorre los elementos del carrito.
        for (ItemCarrito item : items) {

            // Suma el subtotal de cada línea de productos.
            subtotal += item.getSubtotal();
        }

        // Obtiene el costo del método de envío seleccionado.
        int costoEnvio = envio.getCosto();

        // Crea el pedido con el usuario, dirección, fecha, envío,
        // subtotal, costo de envío, total y estado inicial.
        Pedido pedido = new Pedido(usuario, direccion, LocalDateTime.now(), envio,
                subtotal, costoEnvio, subtotal + costoEnvio, EstadoPedido.CONFIRMADO);

        // Recorre los elementos del carrito para crear sus detalles.
        for (ItemCarrito item : items) {

            // Crea un detalle a partir de cada línea del carrito
            // y lo agrega al pedido.
            pedido.agregarDetalle(new DetallePedido(item));
        }

        // ---------- 3. DESCONTAR EL STOCK ----------

        // Recorre los productos agrupados y sus cantidades solicitadas.
        // UPDATE productos SET stock = stock - ? WHERE id = ?
        for (Map.Entry<Long, Integer> pedida : pedidas.entrySet()) {

            // Obtiene el producto correspondiente.
            Producto producto = productos.get(pedida.getKey());

            // Descuenta del inventario las unidades que se compraron.
            producto.setStock(producto.getStock() - pedida.getValue());

            // Guarda el nuevo stock del producto en la base de datos.
            productoRepositorio.save(producto);
        }

        // ---------- 4. GUARDAR EL PEDIDO Y SUS DETALLES ----------

        // Guarda el pedido en la tabla "pedidos".
        // Los detalles también se guardan gracias a cascade = ALL
        // configurado en la relación de la entidad Pedido.
        Pedido guardado = repositorio.save(pedido);

        // ---------- 5. VACIAR EL CARRITO ----------

        // Elimina todos los elementos del carrito del usuario
        // porque la compra ya fue realizada.
        carritoService.vaciar(usuarioId);

        // Retorna el pedido guardado, incluyendo el identificador
        // que generó automáticamente la base de datos.
        return guardado;   // ya tiene el id que generó MySQL
    }

    // ---------- Consultar pedidos ----------

    // Busca un pedido utilizando su identificador.
    public Pedido buscarPorId(Long id) {

        // Si encuentra el pedido, lo retorna; si no, retorna null.
        return repositorio.findById(id).orElse(null);
    }

    // Obtiene el historial de pedidos de un cliente.
    // Los organiza desde el más reciente hasta el más antiguo.
    public List<Pedido> listarDeUsuario(Long usuarioId) {

        // Consulta los pedidos que pertenecen al usuario indicado.
        return repositorio.findByUsuarioIdOrderByIdDesc(usuarioId);
    }

    // Obtiene todos los pedidos registrados.
    // Se utiliza principalmente en el panel del administrador.
    public List<Pedido> listarTodos() {

        // Consulta todos los pedidos ordenados por identificador descendente.
        return repositorio.findAllByOrderByIdDesc();
    }

    /**
     * Permite al administrador modificar el estado de un pedido.
     * Se utiliza para actualizar el seguimiento de la compra.
     */
    @Transactional
    public void cambiarEstado(Long id, EstadoPedido estado) {

        // Busca el pedido por su identificador.
        // Si existe, ejecuta las instrucciones dentro de ifPresent().
        repositorio.findById(id).ifPresent(pedido -> {

            // Actualiza el estado del pedido.
            pedido.setEstado(estado);

            // Guarda los cambios en la base de datos.
            repositorio.save(pedido);
        });
    }
}
