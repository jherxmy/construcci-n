
package com.maquillaje.model;

/**
 * Enum que define los tipos de usuario que pueden utilizar el sistema.
 * Permite identificar los permisos y funciones según el rol del usuario.
 */
public enum Rol {

    // Usuario con permisos para administrar productos, marcas y pedidos.
    ADMIN,

    // Usuario que puede explorar el catálogo y realizar compras.
    CLIENTE
}
