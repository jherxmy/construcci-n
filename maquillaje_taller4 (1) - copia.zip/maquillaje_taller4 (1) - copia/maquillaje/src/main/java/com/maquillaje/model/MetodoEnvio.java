
package com.maquillaje.model;

/*
 * Enum que define los métodos de envío disponibles en la tienda.
 * Cada método tiene un nombre, un costo y un tiempo estimado de entrega.
 */
public enum MetodoEnvio {

    // Envío estándar: tiene un costo de $10.000 y tarda entre 3 y 5 días hábiles.
    ESTANDAR("Envío estándar", 10000, "3 a 5 días hábiles"),

    // Envío express: tiene un costo de $18.000 y tarda aproximadamente 24 horas.
    EXPRESS("Envío express", 18000, "24 horas");

    // Nombre que se mostrará al cliente en la interfaz.
    private final String nombre;

    // Costo correspondiente al método de envío.
    private final int costo;

    // Tiempo estimado para entregar el pedido.
    private final String entrega;

    /*
     * Constructor que recibe los datos de cada método de envío
     * y los asigna a sus respectivos atributos.
     */
    MetodoEnvio(String nombre, int costo, String entrega) {
        this.nombre = nombre;
        this.costo = costo;
        this.entrega = entrega;
    }

    // Devuelve el nombre del método de envío.
    public String getNombre() {
        return nombre;
    }

    // Devuelve el costo del envío.
    public int getCosto() {
        return costo;
    }

    // Devuelve el tiempo estimado de entrega.
    public String getEntrega() {
        return entrega;
    }
}
