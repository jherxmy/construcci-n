
package com.maquillaje.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.maquillaje.model.Rol;
import com.maquillaje.model.Usuario;
import com.maquillaje.seguridad.SesionUsuario;
import com.maquillaje.service.UsuarioService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/*
 * Controlador encargado de gestionar el acceso de los usuarios.
 * Permite iniciar sesión, registrar nuevas cuentas y cerrar sesión.
 */
@Controller
public class AuthController {

    // Servicio encargado de gestionar y validar los usuarios.
    private final UsuarioService usuarioService;

    // Constructor que recibe el servicio mediante inyección de dependencias.
    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // ---------- Inicio de sesión ----------

    // Muestra el formulario de inicio de sesión.
    @GetMapping("/login")
    public String formularioLogin(HttpSession sesion) {

        // Si el usuario ya inició sesión, lo envía a la página correspondiente a su rol.
        if (SesionUsuario.estaAutenticado(sesion)) {
            return SesionUsuario.esAdmin(sesion) ? "redirect:/admin" : "redirect:/";
        }

        return "login";
    }

    // Recibe los datos del formulario y comprueba las credenciales del usuario.
    @PostMapping("/login")
    public String login(@RequestParam("identificador") String identificador,
                        @RequestParam("contrasena") String contrasena,
                        HttpServletRequest request,
                        RedirectAttributes redirect) {

        // Comprueba si el usuario y la contraseña son correctos.
        Usuario usuario = usuarioService.autenticar(identificador, contrasena);

        // Si las credenciales son incorrectas, muestra un mensaje de error.
        if (usuario == null) {
            redirect.addFlashAttribute("error", "Usuario o contraseña incorrectos.");
            redirect.addFlashAttribute("identificador", identificador);
            return "redirect:/login";
        }

        // Cierra la sesión anterior para evitar reutilizar una sesión existente.
        HttpSession anterior = request.getSession(false);
        if (anterior != null) {
            anterior.invalidate();
        }

        // Crea una nueva sesión y guarda en ella los datos del usuario autenticado.
        SesionUsuario.iniciar(request.getSession(true), usuario);

        // Redirige al usuario según su rol: administrador o cliente.
        return usuario.getRol() == Rol.ADMIN ? "redirect:/admin" : "redirect:/";
    }

    // ---------- Registro ----------

    // Muestra el formulario para crear una cuenta nueva.
    @GetMapping("/registro")
    public String formularioRegistro(HttpSession sesion) {

        // Si el usuario ya está autenticado, lo envía a la página principal.
        if (SesionUsuario.estaAutenticado(sesion)) {
            return "redirect:/";
        }

        return "registro";
    }

    // Recibe los datos del formulario y registra un nuevo usuario.
    @PostMapping("/registro")
    public String registrar(@RequestParam("nombreCompleto") String nombreCompleto,
                            @RequestParam("usuario") String usuario,
                            @RequestParam("correo") String correo,
                            @RequestParam("contrasena") String contrasena,
                            @RequestParam("confirmar") String confirmar,
                            RedirectAttributes redirect) {
        try {
            // Comprueba que la contraseña y su confirmación sean iguales.
            if (!contrasena.equals(confirmar)) {
                throw new IllegalArgumentException("Las contraseñas no coinciden.");
            }

            // Los usuarios que se registran desde el formulario público reciben el rol CLIENTE.
            usuarioService.registrar(nombreCompleto, usuario, correo, contrasena, Rol.CLIENTE);

        } catch (IllegalArgumentException e) {

            // Si ocurre un error, envía el mensaje a la pantalla de registro.
            redirect.addFlashAttribute("error", e.getMessage());

            // Conserva los datos escritos para que el usuario no tenga que ingresarlos nuevamente.
            // La contraseña no se conserva por seguridad.
            redirect.addFlashAttribute("nombreCompleto", nombreCompleto);
            redirect.addFlashAttribute("usuarioEscrito", usuario);
            redirect.addFlashAttribute("correo", correo);

            return "redirect:/registro";
        }

        // Informa que la cuenta fue creada y solicita iniciar sesión.
        redirect.addFlashAttribute("mensaje", "¡Cuenta creada! Ahora inicia sesión 💖");

        return "redirect:/login";
    }

    // ---------- Cerrar sesión ----------

    // Finaliza la sesión del usuario que se encuentra conectado.
    @PostMapping("/logout")
    public String logout(HttpSession sesion) {

        // Invalida la sesión y elimina los datos almacenados en ella.
        sesion.invalidate();

        return "redirect:/";
    }
}
